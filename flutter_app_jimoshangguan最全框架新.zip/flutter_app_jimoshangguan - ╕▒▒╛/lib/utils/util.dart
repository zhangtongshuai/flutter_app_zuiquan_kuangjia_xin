import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:url_launcher/url_launcher.dart';

class Util {
  //弹框提示
  static showToast(String message) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIos: 1,
        backgroundColor: ThemeColors.colorHyaline,
        textColor: ThemeColors.colorWhite,
        fontSize: ScreenUtil().setSp(24));
  }

  /// 调起拨号页
  static void launchTelURL(String phone) async {
    String url = 'tel:'+ phone;
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      showToast('拨号失败！');
    }
  }

  static bool isChinaPhoneLegal(String str) {
    return new RegExp('^((13[0-9])|(15[^4])|(166)|(17[0-8])|(18[0-9])|(19[8-9])|(147,145))\\d{8}\$').hasMatch(str);
  }

  static Future<bool> setStorage(String name, String value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(name, value);
  }

  static Future<String> getStorage(String name) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(name);
  }

  static Future<bool> removeStorage(String name) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.remove(name);
  }


  static Future<bool> checkPermission(PermissionGroup permission) async {
    PermissionStatus permissionStatus = await PermissionHandler()
        .checkPermissionStatus(permission);
    if (permissionStatus != PermissionStatus.granted) {
      return await requestPermission(permission);
    } else {
      return true;
    }
  }

  static Future<bool> requestPermission(PermissionGroup permission) async {
    final List<PermissionGroup> permissions = <PermissionGroup>[permission];
    final Map<PermissionGroup,
        PermissionStatus> permissionRequestResult = await PermissionHandler()
        .requestPermissions(permissions);

    return permissionRequestResult[permission] == PermissionStatus.granted;
  }

  static String rand() {
//    var r = Random().nextInt(2147483646);
    var r = DateTime
        .now()
        .millisecondsSinceEpoch;
    return r.toString();
  }

  static String formatTime(DateTime time) {
    int today = DateTime
        .now()
        .day;
    if (time.day == today) {
      return "${time.hour.toString().padLeft(2, "0")}:${time.minute.toString()
          .padLeft(2, "0")}";
    } else if (today - time.day == 1) {
      return "昨天";
    } else if (today - time.day == 2) {
      return "前天";
    } else {
      return "${time.month.toString().padLeft(2, "0")}月${time.day.toString()
          .padLeft(2, "0")}日";
    }
  }

  // 是否是空字符串
  static bool isEmptyString(String str) {
    if (str == null || str.isEmpty) {
      return true;
    }
    return false;
  }

  // 是否不是空字符串
  static bool isNotEmptyString(String str) {
    if (str != null && str.isNotEmpty) {
      return true;
    }
    return false;
  }

  // 🔥格式化手机号为344
  static String formatMobile344(String mobile) {
    if (isEmptyString(mobile)) return '';
    mobile = mobile?.replaceAllMapped(new RegExp(r"(^\d{3}|\d{4}\B)"),
            (Match match) {
          return '${match.group(0)} ';
        });
    if (mobile != null && mobile.endsWith(' ')) {
      mobile = mobile.substring(0, mobile.length - 1);
    }
    return mobile;
  }

  /// 纯数字 ^[0-9]*$
  static bool pureDigitCharacters(String input) {
    final String regex = "^[0-9]*\$";
    return matches(regex, input);
  }

  // 🔥是否为正确的QQ号码、微信号、QQ邮箱
  // - [微信号正则校验，qq正则，邮箱正则,英文名正则](https://blog.csdn.net/qq_29091239/article/details/80075981)
  // - [微信号正则校验](https://blog.csdn.net/unknowna/article/details/50524529)
  static bool validQQ(String input) {
    final String regex = '^[1-9][0-9]{4,9}\$';
    return matches(regex, input);
  }

  static bool validWeChatId(String input) {
    final String regex = '^[a-zA-Z]{1}[-_a-zA-Z0-9]{5,19}\$';
    return matches(regex, input);
  }

  static bool validQQMail(String input) {
    final String regex = '^[1-9][0-9]{4,9}@qq\.com\$';
    return matches(regex, input);
  }

  /// 匹配
  static bool matches(String regex, String input) {
    if (input == null || input.isEmpty) return false;
    return new RegExp(regex).hasMatch(input);
  }

}