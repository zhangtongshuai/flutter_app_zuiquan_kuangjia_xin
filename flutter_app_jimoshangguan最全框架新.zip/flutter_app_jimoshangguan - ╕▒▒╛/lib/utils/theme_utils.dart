
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';

class ThemeUtils {

  static bool isDark(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark;
  }

  static Color getDarkColor(BuildContext context, Color darkColor) {
    return isDark(context) ? darkColor : null;
  }

  static Color getIconColor(BuildContext context) {
    return isDark(context) ? ThemeColors.dark_color333333 : null;
  }
  
  static Color getBackgroundColor(BuildContext context) {
    return Theme.of(context).scaffoldBackgroundColor;
  }

  static Color getDialogBackgroundColor(BuildContext context) {
    return Theme.of(context).canvasColor;
  }
  
  static Color getStickyHeaderColor(BuildContext context) {
    return isDark(context) ? ThemeColors.dark_colorGrey : ThemeColors.colorGrey;
  }

  static Color getDialogTextFieldColor(BuildContext context) {
    return isDark(context) ? ThemeColors.dark_colorGrey : ThemeColors.colorGrey;
  }

  static Color getKeyboardActionsColor(BuildContext context) {
    return isDark(context) ? ThemeColors.dark_colorWhite : ThemeColors.colorWhite;
  }
}