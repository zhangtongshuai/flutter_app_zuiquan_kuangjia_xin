import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/config/router_handlers.dart';
import 'package:flutter_app_jimoshangguan/utils/404.dart';

class Routers {
  static String root = "/";
  static String home = "/home";
  static String login = "/login";
  static String webView = "/webView";
  static String userSetting="/userSetting";
  static String userAddress="/userAddress";
  static String themePage="/themePage";
  static String becomeStore="/becomeStore";
  static String becomePay="/becomePay";
  static void configureRoutes(Router router) {
    router.notFoundHandler = new Handler(handlerFunc:
        (BuildContext context, Map<String, List<String>> parameters) {
      print("handler not find");
      print('找不到路由，404');
      return WidgetNotFound();
    });

    router.define(root, handler: splashHandler);
    router.define(home, handler: homeHandler);
    router.define(login, handler: loginSignHandler);
    router.define(webView, handler: webViewHandler);
    router.define(userSetting, handler: userSettingHandler);
    router.define(userAddress, handler: userAddressHandler);
    router.define(themePage, handler: themePageHandler);
    router.define(becomeStore, handler: becomeStoreHandler);
    router.define(becomePay, handler: becomePayHandler);

  }
}
