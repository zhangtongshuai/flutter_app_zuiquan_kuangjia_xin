import 'package:fluro/fluro.dart';

class Application {
  static Router router;
}
