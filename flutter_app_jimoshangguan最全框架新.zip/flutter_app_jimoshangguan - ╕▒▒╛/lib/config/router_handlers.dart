import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/page/home/mall.dart';
import 'package:flutter_app_jimoshangguan/page/splash/splash.dart';
import 'package:flutter_app_jimoshangguan/page/login/login_sign.dart';
import 'package:flutter_app_jimoshangguan/utils/string_util.dart';
import 'package:flutter_app_jimoshangguan/widgets/webview.dart';
import 'package:flutter_app_jimoshangguan/utils/fluro_convert_utils.dart';
import 'package:flutter_app_jimoshangguan/page/mine/setting.dart';
import 'package:flutter_app_jimoshangguan/page/mine/addressMange.dart';
import 'package:flutter_app_jimoshangguan/page/mine/theme_page.dart';
import 'package:flutter_app_jimoshangguan/page/mine/becomeStore.dart';
import 'package:flutter_app_jimoshangguan/page/mine/pay.dart';


var homeHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return MallMainView();
    });
var splashHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return SplashView();
    });

var loginSignHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return LoginSign();
    });

var webViewHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
  var title = FluroConvertUtil.fluroCnParamsDecode(parameters["title"].first);
  var url = FluroConvertUtil.fluroCnParamsDecode(parameters["url"].first);
  return WebViewPage(url, title);
});

//设置个人信息页面
var userSettingHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return userSetting();
    });

//跳转地址管理
var userAddressHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return userAddress();
    });

var themePageHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return ThemePage();
    });

//跳转成为商家
var becomeStoreHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return becomeStore();
    });

//成为商家支付
var becomePayHandler = Handler(
    handlerFunc: (BuildContext context, Map<String, List<String>> parameters) {
      return becomePay();
    });

