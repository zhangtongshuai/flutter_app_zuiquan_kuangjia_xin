import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class userCard extends StatefulWidget {
  @override
  _userCard createState() => _userCard();
}

class _userCard extends State<userCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width:ScreenUtil().setWidth(493),
      height:ScreenUtil().setWidth(655),
      padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(40), ScreenUtil().setWidth(62), ScreenUtil().setWidth(40), 0),
      decoration: BoxDecoration(
          color: Color(0xFFFFFFFF),
          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                  width: ScreenUtil().setWidth(110),
                  height: ScreenUtil().setWidth(110),
                  decoration:new BoxDecoration(
                      border: Border.all(
                          color: ThemeColors.colorWhite
                      ),
                      borderRadius: BorderRadius.circular(ScreenUtil().setWidth(55))
                  ),
                  child:ClipOval(
                    child: Image.network(
                      'https://pic2.zhimg.com/v2-639b49f2f6578eabddc458b84eb3c6a1.jpg',
                      width: ScreenUtil().setWidth(110),
                      height: ScreenUtil().setWidth(110),
                      fit: BoxFit.cover,
                    ),
                  )
              ),
              SizedBox(width: ScreenUtil().setWidth(22)),
              Column(
                children: <Widget>[
                  Container(
                    alignment: Alignment.topLeft,
                    child:Row(
                      children: <Widget>[
                        Container(
                          width: ScreenUtil().setWidth(200),
                          child:Text(
                            "梅花梅花梅花梅花梅花梅花梅花梅花梅花梅花梅花梅花",
                            style: WordStyles.fontSize32color333DecNot,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    width: ScreenUtil().setWidth(200),
                    margin: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(18), 0.0, 0.0),
                    child: Text(
                      "梅花香自苦寒来梅花香自苦寒来梅花香自苦寒来梅花香自苦寒来",
                      style: WordStyles.fontSize26color333DecNot,
                      overflow: TextOverflow.ellipsis,
                    ),
                  )
                ],
              )
            ],
          ),
          Padding(
              padding: EdgeInsets.fromLTRB(0, ScreenUtil().setWidth(85), 0, 0)
          ),
          Image.network(
            'https://pic2.zhimg.com/v2-639b49f2f6578eabddc458b84eb3c6a1.jpg',
            width: ScreenUtil().setWidth(290),
            height: ScreenUtil().setWidth(290),
            fit: BoxFit.cover,
          ),
        ],
      ),
    );
  }
}
