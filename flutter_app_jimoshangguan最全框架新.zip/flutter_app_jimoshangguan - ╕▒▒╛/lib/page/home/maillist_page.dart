import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/page/maillist/maillist_head.dart';
import 'package:flutter_app_jimoshangguan/page/maillist/maillist_merchant_list.dart';  //商家
import 'package:flutter_app_jimoshangguan/page/maillist/maillist_customer_list.dart';  //客户
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:flutter_app_jimoshangguan/provider/maillist_index.dart';

class MaillistPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new _MaillistPage();
  }
}
class _MaillistPage extends State<MaillistPage> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    final _current = Provider.of<MaillistModel>(context);
    return Column(
      children: <Widget>[
        Container(
          width: double.infinity,
          height: ScreenUtil().setWidth(460),
          child: MaillistHead(),
        ),
        _current.current==0 ? MaillistMerchantList() : MaillistCustomerList()
      ],
    );
  }
}

