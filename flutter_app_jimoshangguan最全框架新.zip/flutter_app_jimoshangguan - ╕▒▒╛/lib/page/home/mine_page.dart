import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_app_jimoshangguan/widgets/userCard.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';
class MinePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<MinePage> {
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      body: new SingleChildScrollView(//SingleChildScrollView
        child: Container(
          child: Column(
            children: <Widget>[
              new Column(
                children: <Widget>[
                  header(context),
                  contantList(),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}


Widget header(context){
  return Stack(
    children: <Widget>[
      Column(
        children: <Widget>[
          Container(
              width: double.infinity,
              height: ScreenUtil().setWidth(519),
              padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30),ScreenUtil().setWidth(80), ScreenUtil().setWidth(30),0.0),
              decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('images/mybj.png'),
                    fit: BoxFit.fill
                ),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    ThemeColors.colorBtnFoot,
                    ThemeColors.colorBtnTop,
                  ],
                ),
              ),
              child:Container(
                  alignment: Alignment.topLeft,
                  child:Column(
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            Strings.MINE,
                            style: WordStyles.fontSize36colorWhite,
                          ),
                          Row(
                            children: <Widget>[
                              InkWell(
                                onTap: (){
                                  print("扫一扫");
                                },
                                child: new Image(image: new AssetImage('images/img_m1.png'),width: ScreenUtil().setWidth(32),),
                              ),
                              SizedBox(width: ScreenUtil().setWidth(30)),
                              InkWell(
                                  onTap: (){
                                    print("设置");
                                    NavigatorUtils.userSetting(context);
                                  },
                                  child: new Image(image: new AssetImage('images/img_m2.png'),width: ScreenUtil().setWidth(34),)
                              ),
                            ],
                          )
                        ],
                      ),
                      userBaseInfo(context),
                      userMoreInfo()
                    ],
                  )
              )
          ),
          Container(
            height:ScreenUtil().setWidth(60),
          )
        ],
      ),
      Positioned(
        top: ScreenUtil().setWidth(477),
        child: todayIncome()
      ),
    ],
  );
}

//个人信息
Widget userBaseInfo(BuildContext context){
  return Container(
    alignment: Alignment.topLeft,
    margin: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(60), 0.0, 0.0),
    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, ScreenUtil().setWidth(50)),
    decoration: BoxDecoration(
      border: Border(
        bottom: BorderSide(
          color:ThemeColors.colorWhiteLight
        )
      )
    ),
    child:Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Row(
          children: <Widget>[
            Container(
              width: ScreenUtil().setWidth(110),
              height: ScreenUtil().setWidth(110),
              decoration:new BoxDecoration(
                border: Border.all(
                  color: ThemeColors.colorWhite
                ),
                borderRadius: BorderRadius.circular(ScreenUtil().setWidth(55))
              ),
              child:ClipOval(
                child: Image.network(
                  'https://pic2.zhimg.com/v2-639b49f2f6578eabddc458b84eb3c6a1.jpg',
                  width: ScreenUtil().setWidth(110),
                  height: ScreenUtil().setWidth(110),
                  fit: BoxFit.cover,
                ),
              )
            ),
            SizedBox(width: ScreenUtil().setWidth(22)),
            Column(
              children: <Widget>[
                Container(
                  alignment: Alignment.topLeft,
                  child:Row(
                    children: <Widget>[
                      Container(
                        width: ScreenUtil().setWidth(200),
                        child:Text(
                          "梅花",
                          style: WordStyles.fontSize32colorWhite,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      InkWell(
                        onTap: (){
                          showDialog<Null>(
                            context: context,
                            barrierDismissible: true,
                            builder: (BuildContext context) {
                              return GestureDetector(
                                onTap: (){
                                  Navigator.of(context).pop();				//退出弹出框
                                },
                                child:Stack(
                                  children: <Widget>[
                                    Container(
                                      decoration: BoxDecoration(
                                          color: Colors.transparent
                                      ),
                                    ),
                                    Positioned(
                                        top: ScreenUtil().setWidth(305),
                                        left: ScreenUtil().setWidth(129),
                                        child: userCard()
                                    )
                                  ],
                                )
                              );
                            },
                          ).then((val) {
                            print(val);
                          });
                        },
                        child:new Image(image: new AssetImage('images/code.png'),width: ScreenUtil().setWidth(32),)
                      ),
                    ],
                  ),
                ),
                Container(
                  alignment: Alignment.topLeft,
                  width: ScreenUtil().setWidth(232),
                  margin: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(18), 0.0, 0.0),
                  child: Text(
                    "梅花香自苦寒来梅花香自苦寒来梅花香自苦寒来梅花香自苦寒来",
                    style: WordStyles.fontSize26colorWhite,
                    overflow: TextOverflow.ellipsis,
                  ),
                )
              ],
            )
          ],
        ),
        InkWell(
          onTap: (){
            NavigatorUtils.becomeStore(context);
          },
          child:Container(
            padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(19), ScreenUtil().setWidth(21), ScreenUtil().setWidth(19), ScreenUtil().setWidth(21)),
            decoration: BoxDecoration(
                border: Border.all(
                    color: ThemeColors.colorWhite
                ),
                borderRadius: BorderRadius.circular(ScreenUtil().setWidth(5))
            ),
            child: Text(Strings.MINE_BECOME,
              style: WordStyles.fontSize28colorWhite,
            ),
          )
        ),
      ],
    ),
  );
}

//个人下部分信息
Widget userMoreInfo(){
  return Container(
    margin: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(25), 0.0, 0.0),
    child: Row(
      children: <Widget>[
        Container(
          width: ScreenUtil().setWidth(344),
          alignment: Alignment.center,
          child: Column(
            children: <Widget>[
              Text(
                "0",
                style:WordStyles.fontSize28colorWhite,
              ),
              SizedBox(height: ScreenUtil().setWidth(10)),
              Text(
                Strings.MINE_SHOP,
                style:WordStyles.fontSize28colorWhite,
              )
            ],
          ),
        ),
        Container(
          width: ScreenUtil().setWidth(1),
          height: ScreenUtil().setWidth(41),
          decoration: BoxDecoration(
            border: Border.all(
              color: ThemeColors.colorWhiteLight
            ),
            color: ThemeColors.colorWhiteLight
          ),
        ),
        Container(
          width: ScreenUtil().setWidth(344),
          alignment: Alignment.center,
          child: Column(
            children: <Widget>[
              Text(
                "0",
                style:WordStyles.fontSize28colorWhite,
              ),
              SizedBox(height: ScreenUtil().setWidth(10)),
              Text(
                Strings.MINE_COS,
                style:WordStyles.fontSize28colorWhite,
              )
            ],
          ),
        ),
      ],
    )
  );
}

//今日收入
Widget todayIncome(){
  return Container(
    width: ScreenUtil().setWidth(690),
    margin:EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
    padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), ScreenUtil().setWidth(25), ScreenUtil().setWidth(30), ScreenUtil().setWidth(25)),
    decoration: BoxDecoration(
      color: ThemeColors.colorWhite,
      boxShadow: [
        BoxShadow(color: Color(0x11333333), offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
      ],
      borderRadius: BorderRadius.circular(ScreenUtil().setWidth(15))
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Row(
          children: <Widget>[
            Text(
              Strings.MINE_ICOME,
              style: WordStyles.fontSize24color999,
            ),
            Text(
              "￥4521",
              style: WordStyles.fontSize32colorRed2,
            )
          ],
        ),
        new Image(image: new AssetImage('images/img_m3.png'),width: ScreenUtil().setWidth(16),)
      ],
    ),
  );
}

//内容条目
Widget contantList(){
  return Padding(
    padding: new EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), ScreenUtil().setWidth(30),ScreenUtil().setWidth(30),ScreenUtil().setWidth(30)),
    child: Container(
      width: ScreenUtil().setWidth(690),
      padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
      decoration: BoxDecoration(
        color: ThemeColors.colorWhite,
        boxShadow: [
          BoxShadow(color: Color(0x11333333), offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
        ],
        borderRadius: BorderRadius.circular(ScreenUtil().setWidth(15))
      ),
      child:Column(
        children: <Widget>[
          InkWell(
            onTap: (){
              print("数据分析");
            },
            child:Container(
              padding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: ScreenUtil().setWidth(1),
                          color: ThemeColors.colorE6E6E6
                      )
                  )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textBaseline: TextBaseline.ideographic,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      new Image(image: new AssetImage('images/img_m5.png'),width: ScreenUtil().setWidth(24),),
                      SizedBox(width: ScreenUtil().setWidth(22),),
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,0.0),
                        child: Text(
                          "${Strings.MINE_DATA}",
                          style: WordStyles.fontSize28color333,
                        ),
                      ),

                    ],
                  ),
                  new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(9),)
                ],
              ),
            ),
          ),
          InkWell(
            onTap: (){
              print("库存管理");
            },
            child:Container(
              padding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: ScreenUtil().setWidth(1),
                          color: ThemeColors.colorE6E6E6
                      )
                  )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textBaseline: TextBaseline.ideographic,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      new Image(image: new AssetImage('images/img_m6.png'),width: ScreenUtil().setWidth(24),),
                      SizedBox(width: ScreenUtil().setWidth(22),),
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,0.0),
                        child: Text(
                          "${Strings.MINE_SIST}",
                          style: WordStyles.fontSize28color333,
                        ),
                      ),

                    ],
                  ),
                  new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(9),)
                ],
              ),
            ),
          ),
          InkWell(
            onTap: (){
              print("账款状态");
            },
            child:Container(
              padding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: ScreenUtil().setWidth(1),
                          color: ThemeColors.colorE6E6E6
                      )
                  )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textBaseline: TextBaseline.ideographic,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      new Image(image: new AssetImage('images/img_m7.png'),width: ScreenUtil().setWidth(24),),
                      SizedBox(width: ScreenUtil().setWidth(22),),
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,0.0),
                        child: Text(
                          "${Strings.MINE_MSTATE}",
                          style: WordStyles.fontSize28color333,
                        ),
                      ),

                    ],
                  ),
                  new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(9),)
                ],
              ),
            ),
          ),
          InkWell(
            onTap: (){
              print("购买订单");
            },
            child:Container(
              padding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: ScreenUtil().setWidth(1),
                          color: ThemeColors.colorE6E6E6
                      )
                  )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textBaseline: TextBaseline.ideographic,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      new Image(image: new AssetImage('images/img_m8.png'),width: ScreenUtil().setWidth(24),),
                      SizedBox(width: ScreenUtil().setWidth(22),),
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,0.0),
                        child: Text(
                          "${Strings.MINE_MORDER}",
                          style: WordStyles.fontSize28color333,
                        ),
                      ),

                    ],
                  ),
                  Row(
                    children: <Widget>[
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0,0.0, 0.0,0.0),
                        child: Text(
                          "3",
                          style: WordStyles.fontSize28color999,
                        ),
                      ),
                      SizedBox(width:ScreenUtil().setWidth(15),),
                      new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(9),)
                    ],
                  )
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () async {
              const url = 'tel:+1 555 010 999';
              if (await canLaunch(url)) {
                await launch(url);
              } else {
                throw 'Could not launch $url';
              }
            },
            child:Container(
              padding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: ScreenUtil().setWidth(1),
                          color: ThemeColors.colorE6E6E6
                      )
                  )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textBaseline: TextBaseline.ideographic,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      new Image(image: new AssetImage('images/img_m9.png'),width: ScreenUtil().setWidth(24),),
                      SizedBox(width: ScreenUtil().setWidth(22),),
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,0.0),
                        child: Text(
                          "${Strings.MINE_CONTACT}",
                          style: WordStyles.fontSize28color333,
                        ),
                      ),

                    ],
                  ),
                  Row(
                    children: <Widget>[
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0,0.0, 0.0,0.0),
                        child: Text(
                          "1 555 010 999",
                          style: WordStyles.fontSize28color999,
                        ),
                      ),
                      SizedBox(width:ScreenUtil().setWidth(15),),
                      new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(9),)
                    ],
                  )
                ],
              ),
            ),
          ),
          InkWell(
            onTap: (){
              print("库存管理");
            },
            child:Container(
              padding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: ScreenUtil().setWidth(1),
                          color: ThemeColors.colorE6E6E6
                      )
                  )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textBaseline: TextBaseline.ideographic,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      new Image(image: new AssetImage('images/img_m10.png'),width: ScreenUtil().setWidth(24),),
                      SizedBox(width: ScreenUtil().setWidth(22),),
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,0.0),
                        child: Text(
                          "${Strings.MINE_INTRO}",
                          style: WordStyles.fontSize28color333,
                        ),
                      ),

                    ],
                  ),
                  new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(9),)
                ],
              ),
            ),
          ),
          InkWell(
            onTap: (){
              print("推广App");
            },
            child:Container(
              padding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: ScreenUtil().setWidth(1),
                          color: ThemeColors.colorE6E6E6
                      )
                  )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textBaseline: TextBaseline.ideographic,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      new Image(image: new AssetImage('images/img_m11.png'),width: ScreenUtil().setWidth(24),),
                      SizedBox(width: ScreenUtil().setWidth(22),),
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,0.0),
                        child: Text(
                          "${Strings.MINE_SHARE}",
                          style: WordStyles.fontSize28color333,
                        ),
                      ),

                    ],
                  ),
                  new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(9),)
                ],
              ),
            ),
          ),
          InkWell(
            onTap: (){
              print("下载App");
            },
            child:Container(
              padding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textBaseline: TextBaseline.ideographic,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      new Image(image: new AssetImage('images/img_m12.png'),width: ScreenUtil().setWidth(24),),
                      SizedBox(width: ScreenUtil().setWidth(22),),
                      new Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, ScreenUtil().setWidth(5)),
                        child: Text(
                          "${Strings.MINE_DOWN}",
                          style: WordStyles.fontSize28color333,
                        ),
                      ),

                    ],
                  ),
                  new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(9),)
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

//弹框二维码
Widget codeDetail(context){

}


