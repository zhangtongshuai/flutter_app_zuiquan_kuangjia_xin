import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/services.dart';
import 'package:flutter_app_jimoshangguan/utils/util.dart';
import 'package:provider/provider.dart';
import 'package:flutter_app_jimoshangguan/provider/login_index.dart';


class LoginForgetW extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}


TextEditingController phoneController = new TextEditingController();
TextEditingController codeController   = new TextEditingController();
TextEditingController passController   = new TextEditingController();

class Page extends State<LoginForgetW> {
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    final _loginIndex = Provider.of<LoginModel>(context);
    return Container(
      color: ThemeColors.colorWhite,
      width: ScreenUtil().setWidth(650),
      alignment: Alignment.center,
      child: Column(
        children: <Widget>[
          LoginPhoneInput(),
          loginCodeInput(),
          loginPassInput(),
          loginButton(context),
          loginBreif(context,_loginIndex),
        ],
      ),
    );
  }
}


Widget LoginPhoneInput(){
  return new Padding(
    padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(25),0.0 ,ScreenUtil().setWidth(25), 0.0),
    child: new Stack(
      alignment: Alignment(1.0, 1.0),
      children: <Widget>[
        new Row(
          children: <Widget>[
            new Expanded(
                child: new TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: new InputDecoration(
                    labelText: Strings.ACCOUNT_PHONE,
                    labelStyle: WordStyles.fontSize30colorBFBFBF,
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorTheme,width: ScreenUtil().setWidth(1))
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorE6E6E6,width: ScreenUtil().setWidth(1)),
                    ),
                    prefixIcon: Icon(Icons.person),
                    fillColor: ThemeColors.colorWhite,
                    filled: true,
                  ),
                )
            )
          ],
        ),
      ],
    ),
  );
}
Widget loginCodeInput(){
  return new Padding(
    padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(25),0.0 ,ScreenUtil().setWidth(25), 0.0),
    child: new Stack(
      alignment: Alignment(1.0, 1.0),
      children: <Widget>[
        new Row(
          children: <Widget>[
            new Expanded(
                child: new TextField(
                  controller: codeController,
                  keyboardType: TextInputType.number,
                  decoration: new InputDecoration(
                    labelText: Strings.ENTER_CODE,
                    labelStyle: WordStyles.fontSize30colorBFBFBF,
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorTheme,width: ScreenUtil().setWidth(1))
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorE6E6E6,width: ScreenUtil().setWidth(1)),
                    ),
                    prefixIcon: Icon(Icons.verified_user),
                    fillColor: ThemeColors.colorWhite,
                    filled: true,
                  ),
                )
            ),
          ],
        ),
        new FlatButton(
            color: ThemeColors.colorWhite,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(29.0),
            ),
            child: Text(
              Strings.GET_CODE,
              style: WordStyles.fontSize24colorThemeUnderline,
            ),
            onPressed: (){
              codeController.clear();
            }
        )
      ],
    ) ,
  );
}


Widget loginPassInput(){
  return new Padding(
    padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(25), 0.0 ,ScreenUtil().setWidth(25), 0.0),
    child: new Stack(
      alignment: Alignment(1.0, 1.0),
      children: <Widget>[
        new Row(
          children: <Widget>[
            new Expanded(
                child: new TextField(
                  controller: passController,
                  obscureText: true,
                  keyboardType: TextInputType.text,
                  decoration: new InputDecoration(
                    labelText: Strings.PASSWORD_NEW,
                    labelStyle: WordStyles.fontSize30colorBFBFBF,
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorTheme,width: ScreenUtil().setWidth(1))
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(style: BorderStyle.solid,color: ThemeColors.colorE6E6E6,width: ScreenUtil().setWidth(1)),
                    ),
                    prefixIcon: Icon(Icons.https),
                    fillColor: ThemeColors.colorWhite,
                    filled: true,
                  ),
                )
            ),
          ],
        ),
      ],
    ),
  );
}

Widget loginButton(BuildContext context){
  return new Container(
    width:  ScreenUtil().setWidth(602),
    height: ScreenUtil().setWidth(88),
    margin: EdgeInsets.only(top: ScreenUtil().setWidth(50)),
    child: new RaisedButton(
      color: ThemeColors.colorTheme,
      splashColor: ThemeColors.colorWathet,
      elevation: 5.0,
      child: new Text(
        Strings.LOGIN,
        style: WordStyles.fontSize32colorWhite,
      ),
      onPressed: (){
        _checkSub(context);
      },
    ),
  );
}

Widget loginBreif(BuildContext context,_loginIndex){
  return Container(
    padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(25), 0.0 ,ScreenUtil().setWidth(25), 0.0),
    margin: EdgeInsets.only(top: ScreenUtil().setWidth(19),bottom: ScreenUtil().setWidth(45) ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Container(
          child: Row(
            children: <Widget>[
              Text(
                Strings.NOT_ACCOUNT,
                style: WordStyles.fontSize28color333,
              ),
              Container(
                margin: EdgeInsets.only(left: ScreenUtil().setWidth(10)),
                child: GestureDetector(
                  onTap: (){
                    print('1111');
//                    NavigatorUtils.goRegister(context);
                    _loginIndex.increment(1);
                  },
                  child: Text(
                    Strings.GO_REGISTER,
                    style: WordStyles.fontSize28colorTheme,
                  ),
                ),
              )
            ],
          ),
        ),
      ],
    ),
  );
}


void _checkSub(BuildContext context){
  String msgStr = "";
  if(!phoneController.text.isNotEmpty ){
    msgStr = Strings.ACCOUNT_PHONE;
  }else if(!Util.isChinaPhoneLegal(phoneController.text)){
    msgStr = Strings.ACCOUNT_CORRECT_PHONE;
  }else  if(!codeController.text.isNotEmpty){
    msgStr = Strings.ENTER_CODE;
  }else  if(!passController.text.isNotEmpty){
    msgStr = Strings.PASSWORD_HINT;
  }

  if(msgStr != ''){
    Util.showToast(msgStr);
  }else{
    NavigatorUtils.goMallMainPage(context);
  }
}

