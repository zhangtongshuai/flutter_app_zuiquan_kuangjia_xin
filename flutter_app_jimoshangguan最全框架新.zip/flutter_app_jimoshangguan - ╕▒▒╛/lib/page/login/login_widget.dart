import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class LoginWidget extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Container(
      height: MediaQuery.of(context).size.height,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          layout(context),
          layfot(context)
        ],
      ),
    );
  }

  Widget layout(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: ScreenUtil().setWidth(160)),
                child: Image.asset('images/logobj1.png',width:ScreenUtil().setWidth(520)),
              ),
            ],
          ),
        ],
      ),
      height: ScreenUtil().setWidth(425),
      width: double.infinity,
      decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('images/bj.png'),
              fit: BoxFit.fill
          )
      ),
    );
  }

  Widget layfot(BuildContext context){
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(bottom: ScreenUtil().setWidth(50)),
            child: Image.asset('images/logobj.png',width:ScreenUtil().setWidth(284)),
          ),
        ],
      ),
    );
  }

}