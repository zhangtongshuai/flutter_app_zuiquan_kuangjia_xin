import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:azlistview/azlistview.dart';
import 'package:lpinyin/lpinyin.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_app_jimoshangguan/page/maillist/maillist_model.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/utils/theme_utils.dart';

//商家通讯录
class MaillistMerchantList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new _MaillistList();
  }
}
class _MaillistList extends State<MaillistMerchantList> {
  List<ContactInfo> _contacts = List();
  List<ContactInfo> _hotContactsList = List();

  int _suspensionHeight =  30;
  int _itemHeight = 76;
  String _hitTag = "";

  @override
  void initState() {
    super.initState();
    loadData();
  }

  void loadData() async {
    _hotContactsList.add(ContactInfo(name: "啊", tagIndex: "A"));
    _hotContactsList.add(ContactInfo(name: "阿", tagIndex: "A"));
    _hotContactsList.add(ContactInfo(name: "啊", tagIndex: "A"));
    _hotContactsList.add(ContactInfo(name: "阿", tagIndex: "A"));
    _hotContactsList.add(ContactInfo(name: "包", tagIndex: "B"));
    _hotContactsList.add(ContactInfo(name: "擦", tagIndex: "C"));
    _hotContactsList.add(ContactInfo(name: "都", tagIndex: "D"));
    _hotContactsList.add(ContactInfo(name: "鄂", tagIndex: "E"));
    _hotContactsList.add(ContactInfo(name: "付", tagIndex: "F"));
    _hotContactsList.add(ContactInfo(name: "葛", tagIndex: "G"));
    _hotContactsList.add(ContactInfo(name: "郝", tagIndex: "H"));
    _hotContactsList.add(ContactInfo(name: "Ia", tagIndex: "I"));
    _hotContactsList.add(ContactInfo(name: "集", tagIndex: "J"));
    _hotContactsList.add(ContactInfo(name: "卡", tagIndex: "K"));
    _hotContactsList.add(ContactInfo(name: "刘", tagIndex: "L"));
    _hotContactsList.add(ContactInfo(name: "猫", tagIndex: "M"));
    _hotContactsList.add(ContactInfo(name: "闹", tagIndex: "N"));
    _hotContactsList.add(ContactInfo(name: "偶", tagIndex: "O"));
    _hotContactsList.add(ContactInfo(name: "跑", tagIndex: "P"));
    _hotContactsList.add(ContactInfo(name: "青", tagIndex: "Q"));
    _hotContactsList.add(ContactInfo(name: "人", tagIndex: "R"));
    _hotContactsList.add(ContactInfo(name: "是", tagIndex: "S"));
    _hotContactsList.add(ContactInfo(name: "图", tagIndex: "T"));
    _hotContactsList.add(ContactInfo(name: "U改", tagIndex: "U"));
    _hotContactsList.add(ContactInfo(name: "v物", tagIndex: "V"));
    _hotContactsList.add(ContactInfo(name: "武汉市", tagIndex: "W"));
    _hotContactsList.add(ContactInfo(name: "小", tagIndex: "X"));
    _hotContactsList.add(ContactInfo(name: "月", tagIndex: "Y"));
    _hotContactsList.add(ContactInfo(name: "字", tagIndex: "Z"));
    _hotContactsList.add(ContactInfo(name: "##", tagIndex: "#"));
    _hotContactsList.add(ContactInfo(name: "95", tagIndex: "#"));

    //加载联系人列表
    rootBundle.loadString('assets/data/contacts.json').then((value) {
      List list = json.decode(value);
      list.forEach((value) {
        _contacts.add(ContactInfo(name: value['name']));
      });
      _handleList(_contacts);
      setState(() {
        _hitTag = _hotContactsList[0].getSuspensionTag();
      });
    });
  }

  void _handleList(List<ContactInfo> list) {
    if (list == null || list.isEmpty) return;
    for (int i = 0, length = list.length; i < length; i++) {
      String pinyin = PinyinHelper.getPinyinE(list[i].name);
      String tag = pinyin.substring(0, 1).toUpperCase();
      list[i].namePinyin = pinyin;
      if (RegExp("[A-Z]").hasMatch(tag)) {
        list[i].tagIndex = tag;
      } else {
        list[i].tagIndex = "#";
      }
    }
    //根据A-Z排序
    SuspensionUtil.sortListBySuspensionTag(_contacts);
  }

  void _onSusTagChanged(String tag) {
    setState(() {
      _hitTag = tag;
    });
  }

  Widget _buildSusWidget(String susTag,isDark) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: ScreenUtil().setWidth(30)),
      height: _suspensionHeight.toDouble(),
      width: double.infinity,
      alignment: Alignment.centerLeft,
      color: isDark?ThemeColors.dark_color0x11333:ThemeColors.color0x11333,
      child: Text(
        '$susTag',
        softWrap: false,
        style: isDark?WordStyles.dark_fontSize22color999:WordStyles.fontSize22color999,
      ),
    );
  }

  Widget _buildListItem(ContactInfo model,isDark) {
    String susTag = model.getSuspensionTag();
    return Column(
      children: <Widget>[
        Offstage(
          offstage: model.isShowSuspension != true,
          child: _buildSusWidget(susTag,isDark),
        ),
        Container(
          height: _itemHeight.toDouble(),
          decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: isDark?ThemeColors.dark_colorE6E6E6:ThemeColors.colorE6E6E6,width: ScreenUtil().setWidth(1)))
          ),
          child: ListTile(
            contentPadding: EdgeInsets.only(top: ScreenUtil().setWidth(20),left: ScreenUtil().setWidth(30),right: ScreenUtil().setWidth(30)),
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(6.0),
              child: Image.network(
                'https://pic2.zhimg.com/v2-639b49f2f6578eabddc458b84eb3c6a1.jpg',
                width: ScreenUtil().setWidth(88),
                height: ScreenUtil().setWidth(88),
                fit: BoxFit.fill,
              ),
            ),
            title: Container(
              height: ScreenUtil().setWidth(88),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Text(
                      '这是经理富华大厦这是经理富华大厦这是经理富华大厦',
                      style: isDark?WordStyles.dark_fontSize28color333:WordStyles.fontSize28color333,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  SizedBox(height: 5.0,),
                  Row(
                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(8), ScreenUtil().setWidth(2), ScreenUtil().setWidth(8),ScreenUtil().setWidth(2)),
                        decoration: BoxDecoration(
                          border: Border.all(color:isDark?ThemeColors.dark_colorE6E6E6:ThemeColors.colorE6E6E6),
                          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(6)),
                          color: isDark?ThemeColors.dark_colorF7F7F7:ThemeColors.colorF7F7F7
                        ),
                        child: Text(
                          '批发',
                          style: isDark?WordStyles.dark_fontSize24color666:WordStyles.fontSize24color666,
                        ),
                      ),
                      SizedBox(width: ScreenUtil().setWidth(16)),
                      Expanded(
                        flex: 1,
                        child: Text(
                          '首饰A首饰A首饰A首饰A',
                          style: isDark?WordStyles.dark_fontSize24color999:WordStyles.fontSize24color999,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      SizedBox(width: ScreenUtil().setWidth(16)),
                      Container(width:ScreenUtil().setWidth(1),height:ScreenUtil().setWidth(20),color: isDark?ThemeColors.dark_colorCCCCCC:ThemeColors.colorCCCCCC,),
                      SizedBox(width: ScreenUtil().setWidth(16)),
                      Expanded(
                        flex: 1,
                        child: Text(
                          '首饰B',
                          style: isDark?WordStyles.dark_fontSize24color999:WordStyles.fontSize24color999,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      SizedBox(width: ScreenUtil().setWidth(16)),
                      Container(width:ScreenUtil().setWidth(1),height:ScreenUtil().setWidth(20),color: isDark?ThemeColors.dark_colorCCCCCC:ThemeColors.colorCCCCCC,),
                      SizedBox(width: ScreenUtil().setWidth(16)),
                      Expanded(
                        flex: 1,
                        child: Text(
                          '首饰C首饰C首饰C首饰C',
                          style: isDark?WordStyles.dark_fontSize24color999:WordStyles.fontSize24color999,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            trailing: IconButton(
                icon: new Image(image: new AssetImage('images/phone.png'),width: ScreenUtil().setWidth(28),),
                color: isDark?ThemeColors.dark_colorTheme:ThemeColors.colorTheme,
                onPressed: (){
                  print('打电话$model');
                }
            ),
            onTap: () {
              print("OnItemClick: $model");
//              Navigator.pop(context, model);
            },
          ),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    bool isDark = ThemeUtils.isDark(context);
    return Expanded(
        flex: 1,
        child: AzListView(
          data: _contacts,
          topData: _hotContactsList,
          itemBuilder: (context, model) => _buildListItem(model,isDark),
          suspensionWidget: _buildSusWidget(_hitTag,isDark),
          isUseRealIndex: false,
          itemHeight: _itemHeight,
          suspensionHeight: _suspensionHeight,
          onSusTagChanged: _onSusTagChanged,
          indexBarBuilder: (BuildContext context, List<String> tags,
              IndexBarTouchCallback onTouch) {
            return Container(
              width: ScreenUtil().setWidth(60),
              child: ListView(
                children: <Widget>[
                  IndexBar(
                    data: tags,
                    itemHeight: 11,
                    onTouch: (details) {
                      onTouch(details);
                    },
                  )
                ],
              ),
            );
          },
          indexHintBuilder: (context, hint) {
            return Container(
              alignment: Alignment.center,
              width:  ScreenUtil().setWidth(120),
              height: ScreenUtil().setWidth(120),
              decoration: BoxDecoration(
                color: isDark?ThemeColors.dark_colorTheme:ThemeColors.colorTheme,
                shape: BoxShape.circle,
              ),
              child:
              Text(hint, style:isDark?WordStyles.fontSize60colorWhite:WordStyles.fontSize60colorWhite),
            );
          },
        )
    );
  }
}

