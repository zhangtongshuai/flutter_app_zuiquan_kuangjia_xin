import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/utils/theme_utils.dart';

//商家通信录
class MaillistMerchant extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<MaillistMerchant> {

  int _tabIndex; // 线上 /线下
  int _modeIndex;  //批发 //零售
  @override
  void initState() {
    super.initState();
    _tabIndex = 0;
    _modeIndex = 0;
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    bool isDark = ThemeUtils.isDark(context);
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), ScreenUtil().setWidth(50), ScreenUtil().setWidth(30), ScreenUtil().setWidth(20)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                listBoxLeft(isDark),
                listBoxRight(isDark)
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget listBoxLeft(isDark){
    return Container(
      decoration: BoxDecoration(
        color: isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          GestureDetector(
            onTap: (){
              setState(() {
                _tabIndex = 0;
              });
            },
            child: Container(
              child: Column(
                children: <Widget>[
                  Text(
                    Strings.ON_LINE,
                    style: TextStyle(
                        color: isDark?ThemeColors.dark_color333333:ThemeColors.color333333,
                        fontSize: ScreenUtil().setSp(28),
                        fontWeight: _tabIndex == 0 ? FontWeight.bold : FontWeight.normal
                    ),
                  ),
                  Container(
                    width: ScreenUtil().setWidth(36),
                    height: ScreenUtil().setWidth(6),
                    margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                    decoration: _tabIndex == 0 ? BoxDecoration(
                        color: isDark?ThemeColors.dark_colorBlue:ThemeColors.colorBlue,
                        boxShadow: [
                          BoxShadow(color: isDark?ThemeColors.dark_color0x11333:ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                        ],
                        borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                    ):BoxDecoration(),
                  )
                ],
              ),
            ),
          ),
          SizedBox(width: ScreenUtil().setWidth(42),),
          GestureDetector(
            onTap: (){
              setState(() {
                _tabIndex = 1;
              });
            },
            child: Container(
              child: Column(
                children: <Widget>[
                  Text(
                    Strings.UNDER_LINE,
                    style: TextStyle(
                        color: isDark?ThemeColors.dark_color333333:ThemeColors.color333333,
                        fontSize: ScreenUtil().setSp(28),
                        fontWeight: _tabIndex == 1 ? FontWeight.bold : FontWeight.normal
                    ),
                  ),
                  Container(
                    width: ScreenUtil().setWidth(36),
                    height: ScreenUtil().setWidth(6),
                    margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                    decoration: _tabIndex == 1 ? BoxDecoration(
                        color: isDark?ThemeColors.dark_colorBlue:ThemeColors.colorBlue,
                        boxShadow: [
                          BoxShadow(color: isDark?ThemeColors.dark_color0x11333:ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                        ],
                        borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                    ):BoxDecoration(),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget listBoxRight(isDark){
    return Container(
      decoration: BoxDecoration(
        color:  isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          GestureDetector(
            onTap: (){
              setState(() {
                _modeIndex = 0;
              });
            },
            child: Container(
              child: Row(
                children: <Widget>[
                  Container(
                    width: ScreenUtil().setWidth(11),
                    height: ScreenUtil().setWidth(11),
                    color: _modeIndex == 0 ? ThemeColors.colorTheme : ThemeColors.colorWhite,
                  ),
                  SizedBox(width:ScreenUtil().setWidth(20)),
                  Text(
                    Strings.WHOLESALE,
                    style: TextStyle(
                      color: _modeIndex == 0 ? ThemeColors.colorTheme : isDark?ThemeColors.dark_color333333:ThemeColors.color333333,
                      fontSize: ScreenUtil().setSp(28),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(width: ScreenUtil().setWidth(42),),
          GestureDetector(
            onTap: (){
              setState(() {
                _modeIndex = 1;
              });
            },
            child: Container(
              child: Row(
                children: <Widget>[
                  Container(
                    width: ScreenUtil().setWidth(11),
                    height: ScreenUtil().setWidth(11),
                    color: _modeIndex == 1 ? ThemeColors.colorTheme : ThemeColors.colorWhite,
                  ),
                  SizedBox(width:ScreenUtil().setWidth(20) ,),
                  Text(
                    Strings.RETAIL,
                    style: TextStyle(
                      color: _modeIndex == 1 ? ThemeColors.colorTheme : isDark?ThemeColors.dark_color333333:ThemeColors.color333333,
                      fontSize: ScreenUtil().setSp(28),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


}

