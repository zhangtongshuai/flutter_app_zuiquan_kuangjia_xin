import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/page/maillist/maillist_merchant.dart';  //商家界面
import 'package:flutter_app_jimoshangguan/page/maillist/maillist_customer.dart';  //客户界面
import 'package:provider/provider.dart';
import 'package:flutter_app_jimoshangguan/provider/maillist_index.dart';
import 'package:flutter_app_jimoshangguan/utils/theme_utils.dart';

class MaillistHead extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

TextEditingController searchController = new TextEditingController();

class Page extends State<MaillistHead> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    final _current = Provider.of<MaillistModel>(context);
    bool isDark = ThemeUtils.isDark(context);
    return Scaffold(
      backgroundColor: isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite,
      body: new SingleChildScrollView(
        child: Column(
          children: <Widget>[
            header(context,_current,isDark),
          ],
        ),
      ),
    );
  }

  Widget header(BuildContext context,_current,isDark){
    return Stack(
      children: <Widget>[
        Column(
          children: <Widget>[
            Container(
                width: double.infinity,
                height: ScreenUtil().setWidth(350),
                padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30),ScreenUtil().setWidth(68), ScreenUtil().setWidth(30),0.0),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end:  Alignment.bottomCenter,
                    colors: [
                      isDark?ThemeColors.dark_colorBtnBottom:ThemeColors.colorBtnBottom,
                      isDark?ThemeColors.dark_colorBtnTop:ThemeColors.colorBtnTop,
                    ],
                  ),
                ),
                child:Container(
                    alignment: Alignment.topLeft,
                    child:Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(
                              Strings.MAILLIST,
                              style: isDark?WordStyles.dark_fontSize36colorCCC:WordStyles.fontSize36colorWhite,
                            ),
                            InkWell(
                              onTap: (){
                                print("加好友");
                              },
                              child: new Image(image: new AssetImage('images/img_m13.png'),width: ScreenUtil().setWidth(32),),
                            ),
                          ],
                        ),
                        Container(
                          margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                          child: Text(
                            '共'+'10'+'个商家，'+'11'+'个用户，'+'100'+'个好友',
                            style: isDark?WordStyles.dark_fontSize24colorCCC:WordStyles.fontSize24colorWhite,
                          ),
                        ),
                        Container(
                          height: ScreenUtil().setWidth(68),
                          margin: EdgeInsets.only(top: ScreenUtil().setWidth(30)),
                          child: new Stack(
                            alignment: Alignment(1.0, 1.0),
                            children: <Widget>[
                              new Row(
                                children: <Widget>[
                                  new Expanded(
                                      child: new TextField(
                                        cursorColor: isDark?ThemeColors.dark_colorTheme:ThemeColors.colorTheme,
                                        controller: searchController,
                                        keyboardType: TextInputType.text,
                                        scrollPadding: EdgeInsets.zero,
                                        decoration: new InputDecoration(
                                          contentPadding: EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
                                          isDense: true,
                                          hintText: Strings.SEARCH,
                                          hintStyle: isDark?WordStyles.dark_fontSize28color333:WordStyles.fontSize28color333,
                                          border: OutlineInputBorder(borderSide: BorderSide.none,borderRadius: BorderRadius.circular(5)),
                                          prefixIcon: Icon(Icons.search),
                                          fillColor: isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite,
                                          filled: true,
                                        ),
                                        style: isDark?WordStyles.dark_fontSize28color333:WordStyles.fontSize28color333,
                                      )
                                  )
                                ],
                              ),
                            ],
                          ),
                        )
                      ],
                    )
                )
            ),
            Column(
              children: <Widget>[
                _current.current==0 ? MaillistMerchant() : MaillistCustomer()
              ],
            )
          ],
        ),
        Positioned(
            top: ScreenUtil().setWidth(278),
            child: listBox(_current,isDark)
        ),
      ],
    );
  }

  Widget listBox(_current,isDark){
    return Container(
      width: ScreenUtil().setWidth(690),
      margin:EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
      padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(15), 0.0, ScreenUtil().setWidth(15)),
      decoration: BoxDecoration(
          color: isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite,
          boxShadow: [
            BoxShadow(color: isDark?ThemeColors.dark_color0x11333:ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
          ],
          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Expanded(
            flex: 1,
            child: GestureDetector(
              onTap: (){
                _current.increment(0);
              },
              child: Container(
                color:  isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite,
                child: Column(
                  children: <Widget>[
                    Text(
                      Strings.BUSINESS,
                      style: TextStyle(
                          color: isDark?ThemeColors.dark_color333333:ThemeColors.color333333,
                          fontSize: _current.current == 0 ? ScreenUtil().setSp(36) : ScreenUtil().setSp(32),
                          fontWeight: _current.current == 0 ? FontWeight.bold : FontWeight.normal
                      ),
                    ),
                    Container(
                      width: ScreenUtil().setWidth(36),
                      height: ScreenUtil().setWidth(6),
                      margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                      decoration: _current.current == 0 ? BoxDecoration(
                          color: isDark?ThemeColors.dark_colorBlue:ThemeColors.colorBlue,
                          boxShadow: [
                            BoxShadow(color:isDark?ThemeColors.dark_color0x11333:ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                          ],
                          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                      ):BoxDecoration(),
                    )
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child:GestureDetector(
              onTap: (){
                setState(() {
                  _current.increment(1);
                });
              },
              child: Container(
                color:  isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite,
                child: Column(
                  children: <Widget>[
                    Text(
                      Strings.CUSTOMER,
                      style: TextStyle(
                          fontSize: _current.current == 1 ? ScreenUtil().setSp(36) : ScreenUtil().setSp(32),
                          fontWeight: _current.current == 1 ? FontWeight.bold : FontWeight.normal
                      ),
                    ),
                    Container(
                      width: ScreenUtil().setWidth(36),
                      height: ScreenUtil().setWidth(6),
                      margin: EdgeInsets.only(top: ScreenUtil().setWidth(6)),
                      decoration: _current.current == 1 ? BoxDecoration(
                          color: isDark?ThemeColors.dark_colorBlue:ThemeColors.colorBlue,
                          boxShadow: [
                            BoxShadow(color: isDark?ThemeColors.dark_color0x11333:ThemeColors.color0x11333, offset: Offset(2,ScreenUtil().setWidth(8)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
                          ],
                          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10))
                      ):BoxDecoration(),
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

}

