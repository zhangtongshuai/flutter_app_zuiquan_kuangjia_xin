import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/common/common.dart';
import 'package:flustars/flustars.dart' as flutter_stars;
import 'package:flutter_app_jimoshangguan/provider/theme_provider.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_app_jimoshangguan/utils/theme_utils.dart';

class ThemePage extends StatefulWidget {
  @override
  _ThemePageState createState() => _ThemePageState();
}

class _ThemePageState extends State<ThemePage> {

  var _list = ['跟随系统', '开启', '关闭'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await flutter_stars.SpUtil.getInstance();
    });
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    String theme = flutter_stars.SpUtil.getString(Constant.theme);
    String themeMode;
    bool isDark = ThemeUtils.isDark(context);
    print(isDark);
    print('夜间模式状态');
    switch(theme) {
      case 'Dark':
        themeMode = _list[1];
        break;
      case 'Light':
        themeMode = _list[2];
        break;
      default:
        themeMode = _list[0];
        break;
    }
    return Scaffold(
      appBar: PreferredSize(
          child:AppBar(
            elevation: 0.2,
            centerTitle: true,
            iconTheme: IconThemeData(),
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios),
              color:isDark ? ThemeColors.dark_backColor : ThemeColors.backColor,
              iconSize: ScreenUtil().setSp(42),
              onPressed: (){
                Navigator.of(context).pop();				//退出弹出框
              },
            ),
            title: new Text(
              Strings.NIGHT_MODE,
              textAlign:TextAlign.center,
              style:isDark ? WordStyles.fontSize36colorWhite : WordStyles.fontSize36color333333,
            ),
            backgroundColor: isDark ? ThemeColors.dark_colorF7F7F7Head : ThemeColors.colorF7F7F7Head,
          ),
          preferredSize: Size.fromHeight(ScreenUtil().setWidth(92)
          )
      ),
      body: ListView.separated(
          shrinkWrap: true,
          itemCount: _list.length,
          separatorBuilder: (_, index) {
            return const Divider();
          },
          itemBuilder: (_, index) {
            return InkWell(
              onTap: () => Provider.of<ThemeProvider>(context, listen: false).setTheme(index == 0 ? ThemeMode.system : (index == 1 ? ThemeMode.dark : ThemeMode.light)),
              child: Container(
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                height: 50.0,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                          _list[index],
                        style:  isDark ? WordStyles.dark_fontSize28color333 : WordStyles.fontSize28color333,
                      ),
                    ),
                    Opacity(
                      opacity: themeMode == _list[index] ? 1 : 0,
                      child: Icon(Icons.done, color: isDark ? ThemeColors.dark_colorTheme : ThemeColors.colorTheme)
                    )
                  ],
                ),
              ),
            );
          }
      ),
    );
  }
}
