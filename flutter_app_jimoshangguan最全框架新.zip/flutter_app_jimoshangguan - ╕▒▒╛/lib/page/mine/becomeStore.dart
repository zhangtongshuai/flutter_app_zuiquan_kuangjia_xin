import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';
import 'package:photo/photo.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:flutter_app_jimoshangguan/utils/util.dart';
import 'package:flutter_app_jimoshangguan/utils/theme_utils.dart';
class becomeStore extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<becomeStore> {
  @override
  String currentSelected = "";
  var shopType=0;
  TextEditingController userShopAddressText = TextEditingController();
  TextEditingController userShopAreaText = TextEditingController();
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    bool isDark = ThemeUtils.isDark(context);
    return layout(context,isDark);
  }
  void pickAssets() async {
    List<AssetEntity> assetList = await PhotoPicker.pickAsset(context: context);
    /// Use assetList to do something.
  }
  Widget layout(BuildContext context,isDark) {
    return new Scaffold(
      appBar:PreferredSize(
          child:AppBar(
            elevation: 0.2,
            centerTitle: true,
            iconTheme: IconThemeData(),
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios),
              color:isDark?ThemeColors.dark_backColor:ThemeColors.backColor,
              iconSize: ScreenUtil().setSp(42),
              onPressed: (){
                Navigator.of(context).pop();				//退出弹出框
              },
            ),
            title: new Text(
              Strings.MINE_BECOME,
              textAlign:TextAlign.center,
              style:isDark?WordStyles.dark_fontSize36color333333:WordStyles.fontSize36color333333,
            ),
            actions: <Widget>[
              Container(
                padding:EdgeInsets.fromLTRB(0.0, 0.0, ScreenUtil().setWidth(30), 0.0),
                height: ScreenUtil().setWidth(92),
                alignment: Alignment.centerLeft,
                child: InkWell(
                  onTap: (){
                    print("完成");
                    submitShopInfo(context);
                  },
                  child:Text(Strings.COMPLETE,style:isDark?WordStyles.dark_fontSize32colorBtnTop:WordStyles.fontSize32colorBtnTop,),
                )
              )
            ],
            backgroundColor:isDark?ThemeColors.dark_colorF7F7F7Head:ThemeColors.colorF7F7F7Head,
          ),
          preferredSize: Size.fromHeight(ScreenUtil().setWidth(92))),
          body: new ListView(
            children: <Widget>[
              becomeTitle(Strings.MINE_STOREADD,isDark),
              shopAddress(isDark),
              becomeTitle(Strings.MINE_STROEAREA,isDark),
              shopArea(isDark),
              becomeTitle(Strings.MINE_LICENSE,isDark),
              choiceImage(isDark),
              becomeTitle(Strings.MINE_STORETYPE,isDark),
              choiceShopType()
            ],
          ),
      );
  }
  //标题
  Widget becomeTitle(titlename,isDark){
    return Container(
      padding: EdgeInsets.all(ScreenUtil().setWidth(30)),
      decoration: BoxDecoration(
        color: isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite
      ),
      child: Text(
        titlename,
        style: isDark?WordStyles.dark_fontSize28color333:WordStyles.fontSize28color333,
      ),
    );
  }

  Widget shopAddress(isDark){
    return Container(
      margin: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30),0.0),
      padding:EdgeInsets.fromLTRB(ScreenUtil().setWidth(10), 0.0, ScreenUtil().setWidth(10),0.0) ,
      decoration: BoxDecoration(
        color: isDark?ThemeColors.dark_colorF7F7F7:ThemeColors.colorF7F7F7,
        border:Border.all(
          color: isDark?ThemeColors.dark_colorE6E6E6:ThemeColors.colorE6E6E6
        )
      ),
      child:Container(
        alignment: Alignment.topLeft,
        width: ScreenUtil().setWidth(650),
        height:ScreenUtil().setWidth(67.8) ,
//        margin: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, ScreenUtil().setWidth(10)),
        child: new TextField(
          obscureText: false,
          textAlign:TextAlign.left,
          controller: userShopAddressText,
          keyboardType: TextInputType.text,
          maxLines:1,
          decoration: InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(2), 0.0,ScreenUtil().setWidth(30)),
              border: InputBorder.none,
              hintText: "",
              hintStyle: isDark?WordStyles.dark_fontSize28color5A6B79:WordStyles.fontSize28color5A6B79
          ),
          style:isDark?WordStyles.dark_fontSize28color5A6B79:WordStyles.fontSize28color5A6B79,
        ),
      ),
    );
  }
  Widget shopArea(isDark){
    return Container(
      margin: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30),0.0),
      padding:EdgeInsets.fromLTRB(ScreenUtil().setWidth(10), 0.0, ScreenUtil().setWidth(10),0.0) ,
      decoration: BoxDecoration(
          color: isDark?ThemeColors.dark_colorF7F7F7:ThemeColors.colorF7F7F7,
          border:Border.all(
              color: isDark?ThemeColors.dark_colorE6E6E6:ThemeColors.colorE6E6E6
          )
      ),
      child:Container(
        alignment: Alignment.topLeft,
        width: ScreenUtil().setWidth(650),
        height:ScreenUtil().setWidth(67.8) ,
//        margin: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, ScreenUtil().setWidth(10)),
        child: new TextField(
          obscureText: false,
          textAlign:TextAlign.left,
          controller: userShopAreaText,
          keyboardType: TextInputType.text,
          maxLines:1,
          decoration: InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(0.0,ScreenUtil().setWidth(2), 0.0,ScreenUtil().setWidth(30)),
              border: InputBorder.none,
              hintText: "",
              hintStyle: isDark?WordStyles.dark_fontSize28color5A6B79:WordStyles.fontSize28color5A6B79
          ),
          style: isDark?WordStyles.dark_fontSize28color5A6B79:WordStyles.fontSize28color5A6B79,
        ),
      ),
    );
  }
  //选择图片
  Widget choiceImage(isDark){
    return Container(
      margin: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
      child: Row(
        children: <Widget>[
          Stack(
            children: <Widget>[
              Container(
                child: Image.network(
                  'https://pic2.zhimg.com/v2-639b49f2f6578eabddc458b84eb3c6a1.jpg',
                  width: ScreenUtil().setWidth(123),
                  height: ScreenUtil().setWidth(123),
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: -4.0,
                right: 0.0,
                width: ScreenUtil().setWidth(20),
                child:InkWell(
                  onTap: (){
                    print("删除图片");
                  },
                  child: Text("×",style:TextStyle(color: isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite),),
                )
              )
            ],
          ),
          SizedBox(width: ScreenUtil().setWidth(30),),
          InkWell(
            onTap: (){
              _pickAsset(PickType.onlyImage);
            },
            child: Container(
              child:Container(
                width:ScreenUtil().setWidth(124),
                height: ScreenUtil().setWidth(124),
                decoration: BoxDecoration(
                    color: isDark?ThemeColors.dark_colorF7F7F7:ThemeColors.colorF7F7F7,
                    border:Border.all(
                        color: isDark?ThemeColors.dark_colorE6E6E6:ThemeColors.colorE6E6E6
                    )
                ),
                child: Icon(Icons.add,size: ScreenUtil().setWidth(43),color: isDark?ThemeColors.dark_colorD9D9D9:ThemeColors.colorD9D9D9,),
            ),
          ),
          )
        ],
      )
    );
  }

  //选择类型
  Widget choiceShopType(){
    return Container(
      margin: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
      child:Row(
        children: <Widget>[
          InkWell(
            onTap: (){
              print("切换经营类型");
              setState(() {
                shopType=0;
              });
            },
            child: Row(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(top: ScreenUtil().setWidth(5)),
                  child:new Image(image: shopType==0?new AssetImage('images/iconp01.png'):new AssetImage('images/iconp02.png'),width: ScreenUtil().setWidth(25),),
                ),
                SizedBox(width:ScreenUtil().setWidth(15)),
                Text(Strings.WHOLESALE,style: shopType==0?WordStyles.fontSize28color6999F1:WordStyles.fontSize28color666666,)
              ],
            ),
          ),
          SizedBox(width:ScreenUtil().setWidth(100)),
          InkWell(
            onTap: (){
              print("切换经营类型");
              setState(() {
                shopType=1;
              });
            },
            child: Row(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(top: ScreenUtil().setWidth(5)),
                  child:new Image(image: shopType==0?new AssetImage('images/iconp02.png'):new AssetImage('images/iconp01.png'),width: ScreenUtil().setWidth(25),),
                ),
                SizedBox(width:ScreenUtil().setWidth(15)),
                Text(Strings.RETAIL,style: shopType==0?WordStyles.fontSize28color666666:WordStyles.fontSize28color6999F1,)
              ],
            ),
          )
        ],
      )
    );
  }
  void _testPhotoListParams() async {
    var assetPathList = await PhotoManager.getImageAsset();
    _pickAsset(PickType.all, pathList: assetPathList);
  }
  void _pickAsset(PickType type, {List<AssetPathEntity> pathList}) async {
    List<AssetEntity> imgList = await PhotoPicker.pickAsset(
      context: context,
      themeColor:ThemeColors.colorTheme,
      textColor: Colors.white,
      padding: 1.0,
      dividerColor: Colors.grey,
      disableColor: Colors.grey.shade300,
      itemRadio: 0.88,
      maxSelected: 1,
      provider: I18nProvider.chinese,
      rowCount: 3,
      thumbSize: 150,
      sortDelegate: SortDelegate.common,
      checkBoxBuilderDelegate: DefaultCheckBoxBuilderDelegate(
        activeColor: Colors.white,
        unselectedColor: Colors.white,
        checkColor:ThemeColors.colorTheme,
      ),
      badgeDelegate: const DurationBadgeDelegate(),
      pickType: type,
      photoPathList: pathList,
    );
    if (imgList == null || imgList.isEmpty) {
//      showToast("No pick item.");
      print("No pick item.");
      return;
    } else {
      List<String> r = [];
      for (var e in imgList) {
        var file = await e.file;
        r.add(file.absolute.path);
      }
      currentSelected = r.join("\n\n");
      List<AssetEntity> preview = [];
      preview.addAll(imgList);
//      Navigator.push(context,
//          MaterialPageRoute(builder: (_) => PreviewPage(list: preview)));
    }
    setState(() {});
  }
  void routePage(Widget widget) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) {
          return widget;
        },
      ),
    );
  }
  //提交
  void submitShopInfo(BuildContext context){
    String msgStr = "";
    if(!userShopAddressText.text.isNotEmpty ){
      Util.showToast(Strings.INPUTADDRESS);
    }else{
      NavigatorUtils.becomePay(context);
    }
  }
}


