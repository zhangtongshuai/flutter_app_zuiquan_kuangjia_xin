import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';
import 'package:flustars/flustars.dart' as flutter_stars;
import 'package:flutter_app_jimoshangguan/common/common.dart';
import 'package:flutter_app_jimoshangguan/utils/theme_utils.dart';

class userSetting extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<userSetting> {
  @override

  TextEditingController userNameController = TextEditingController();
  TextEditingController userShopNameController = TextEditingController();
  TextEditingController userShopTypeController = TextEditingController();
  String themeMode;
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    String theme = flutter_stars.SpUtil.getString(Constant.theme);
    bool isDark = ThemeUtils.isDark(context);
    switch(theme) {
      case 'Dark':
        themeMode = '开启';
        break;
      case 'Light':
        themeMode = '关闭';
        break;
      default:
        themeMode = '跟随系统';
        break;
    }
    return layout(context,isDark);
  }

  Widget layout(BuildContext context,isDark) {
    return new Scaffold(
      appBar:PreferredSize(
          child:AppBar(
            elevation: 0.2,
            centerTitle: true,
            iconTheme: IconThemeData(),
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios),
              color:isDark ? ThemeColors.dark_backColor : ThemeColors.backColor,
              iconSize: ScreenUtil().setSp(42),
              onPressed: (){
                Navigator.of(context).pop();				//退出弹出框
              },
            ),
            title: new Text(
              Strings.Stting,
              textAlign:TextAlign.center,
              style:isDark ? WordStyles.fontSize36colorWhite : WordStyles.fontSize36color333333,
            ),
            actions: <Widget>[
              Container(
                padding:EdgeInsets.fromLTRB(0.0, 0.0, ScreenUtil().setWidth(30), 0.0),
                height: ScreenUtil().setWidth(92),
                alignment: Alignment.centerLeft,
                child: GestureDetector(
                  onTap: (){
                    print('完成');
                  },
                  child: Text(Strings.COMPLETE,style:isDark ? WordStyles.dark_fontSize32colorBtnTop : WordStyles.fontSize32colorBtnTop,),
                ),
              )
            ],
            backgroundColor: isDark ? ThemeColors.dark_colorF7F7F7Head : ThemeColors.colorF7F7F7Head,
          ),
          preferredSize: Size.fromHeight(ScreenUtil().setWidth(92))),
          body: new ListView(
            children: <Widget>[
              userTopInfo(isDark),
              splteHeight(isDark),
              userDetail(isDark),
              splteHeight(isDark),
              userAddress(context,isDark),
              splteHeight(isDark),
              newsAdvice(context,isDark),
              splteHeight(isDark),
              nightMode(context,isDark),
              splteHeight(isDark),
              exitLogin(isDark)
            ],
          ),
      );
  }
  //顶部头像信息和姓名
  Widget userTopInfo(isDark){
      return Container(
        padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(40), ScreenUtil().setWidth(49), ScreenUtil().setWidth(40), ScreenUtil().setWidth(49)),
        child:new Row(
          children: <Widget>[
            Stack(
              children: <Widget>[
                Container(
                  width: ScreenUtil().setWidth(138),
                  height: ScreenUtil().setWidth(138),
                ),
                Positioned(
                    top:ScreenUtil().setWidth(0),
                    left:ScreenUtil().setWidth(0),
                    child:Container(
                        width: ScreenUtil().setWidth(128),
                        height: ScreenUtil().setWidth(128),
                        child:ClipRRect(
                          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(10)),
                          child: Image.network(
                            'https://pic2.zhimg.com/v2-639b49f2f6578eabddc458b84eb3c6a1.jpg',
                            width: ScreenUtil().setWidth(128),
                            height: ScreenUtil().setWidth(128),
                            fit: BoxFit.cover,
                          ),
                        )
                    )
                ),
                Positioned(
                    top:ScreenUtil().setWidth(103),
                    left:ScreenUtil().setWidth(103),
                    child: Container(
                      alignment: Alignment.center,
                      width: ScreenUtil().setWidth(32),
                      height: ScreenUtil().setWidth(32),
                      decoration: BoxDecoration(
                        color:isDark ? ThemeColors.dark_cameBACKGROUND : ThemeColors.cameBACKGROUND,
                        borderRadius: BorderRadius.circular(ScreenUtil().setWidth(100))
                      ),
                      child: Icon(
                        Icons.camera_alt,
                        color:isDark ? ThemeColors.colorWhite : ThemeColors.colorWhite,
                        size: ScreenUtil().setWidth(19),
                      ),
                    )
                ),
              ],
            ),
            Container(
              width: ScreenUtil().setWidth(52),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Container(
                  alignment: Alignment.topLeft,
                  width: ScreenUtil().setWidth(120),
                  child: new TextField(
                    obscureText: false,
                    textAlign:TextAlign.left,
                    controller: userNameController,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "梅云文",
                      hintStyle: isDark ? WordStyles.dark_fontSize32color333DecNot : WordStyles.dark_fontSize32color333DecNot
                    ),
                    style:isDark ? WordStyles.dark_fontSize32color333DecNot : WordStyles.fontSize32color333DecNot,
                  ),
                ),
                SizedBox(width:ScreenUtil().setWidth(20)),
                Icon(
                  Icons.edit,
                  color: isDark ? ThemeColors.dark_colorBFBFBF : ThemeColors.colorBFBFBF,
                  size: ScreenUtil().setWidth(24),
                )
              ],
            )

          ],
        ),
      );
  }
  //分割线的高度
  Widget splteHeight(isDark){
    return Container(
      height: ScreenUtil().setWidth(8),
      decoration: BoxDecoration(
        color: isDark ? ThemeColors.dark_colorF7F7F7 : ThemeColors.colorF7F7F7
      ),
    );
  }
  //电话等信息
  Widget userDetail(isDark){
    return Container(
      padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
      decoration: BoxDecoration(
        color: isDark ? ThemeColors.dark_colorWhite : ThemeColors.colorWhite
      ),
      child: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(39), 0.0, ScreenUtil().setWidth(39)),
            decoration: BoxDecoration(
              border: Border(
                bottom:BorderSide(
                  color: isDark ? ThemeColors.dark_settingUNDERLINE : ThemeColors.settingUNDERLINE
                )
              )
            ),
            child:Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Container(
                  child: Text(
                    Strings.STTINGPHONE,
                    style: isDark ? WordStyles.dark_fontSize28color333 : WordStyles.fontSize28color333,
                  ),
                ),
                Container(
                  child: Text(
                      "121212121212",
                    style: WordStyles.fontSize28color5A6B79,
                  ),
                ),
              ],
            )
          ),
          Container(
              padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(39), 0.0, ScreenUtil().setWidth(39)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom:BorderSide(
                          color: isDark ? ThemeColors.dark_settingUNDERLINE : ThemeColors.settingUNDERLINE
                      )
                  )
              ),
              child:Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: Text(
                      Strings.ACCOUNT,
                      style: isDark ? WordStyles.dark_fontSize28color333 : WordStyles.fontSize28color333,
                    ),
                  ),
                  Container(
                    child: Text(
                      "121212121212",
                      style: isDark ? WordStyles.dark_fontSize28color5A6B79 :  WordStyles.fontSize28color5A6B79,
                    ),
                  ),
                ],
              )
          ),
          Container(
              padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(10), 0.0, ScreenUtil().setWidth(10)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom:BorderSide(
                          color: isDark ? ThemeColors.dark_settingUNDERLINE : ThemeColors.settingUNDERLINE
                      )
                  )
              ),
              child:Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: Text(
                      Strings.SHOPNAME,
                      style: isDark ? WordStyles.dark_fontSize28color333 : WordStyles.fontSize28color333,
                    ),
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    width: ScreenUtil().setWidth(120),
                    child: new TextField(
                      obscureText: false,
                      textAlign:TextAlign.right,
                      controller: userShopNameController,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(vertical:0.0),
                        border: InputBorder.none,
                        hintText: "未发货",
                        hintStyle:isDark ? WordStyles.dark_fontSize28color5A6B79 :  WordStyles.fontSize28color5A6B79,
                      ),
                      style:isDark ? WordStyles.dark_fontSize28color5A6B79 :  WordStyles.fontSize28color5A6B79,
                    ),
                  ),
                ],
              )
          ),
          Container(
              padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(10), 0.0, ScreenUtil().setWidth(10)),
              child:Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    child: Text(
                      Strings.SHOPTYPE,
                      style: isDark ? WordStyles.dark_fontSize28color333 : WordStyles.fontSize28color333,
                    ),
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    width: ScreenUtil().setWidth(120),
                    child: new TextField(
                      obscureText: false,
                      textAlign:TextAlign.right,
                      controller: userShopTypeController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.symmetric(vertical:0.0),
                          border: InputBorder.none,
                          hintText: "未发货",
                          hintStyle: isDark ? WordStyles.dark_fontSize28color5A6B79 :  WordStyles.fontSize28color5A6B79,
                      ),
                      style:isDark ? WordStyles.dark_fontSize28color5A6B79 :  WordStyles.fontSize28color5A6B79,
                    ),
                  ),
                ],
              )
          ),
        ],
      ),
    );
  }
  //地址管理
  Widget userAddress(BuildContext context,isDark){
    return GestureDetector(
      onTap: (){
        NavigatorUtils.userAddress(context);
      },
      child: Container(
        padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
        decoration: BoxDecoration(
            color: isDark ? ThemeColors.dark_colorWhite : ThemeColors.colorWhite
        ),
        child: Column(
          children: <Widget>[
            Container(
                padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(39), 0.0, ScreenUtil().setWidth(39)),
                child:Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      child: Text(
                        Strings.ADDRESS,
                        style: isDark ? WordStyles.dark_fontSize28color333 : WordStyles.fontSize28color333,
                      ),
                    ),
                    new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(10),)
                  ],
                )
            ),
          ],
        ),
      ),
    );
  }
  //新消息提醒
  Widget newsAdvice(BuildContext context,isDark){
    return GestureDetector(
      onTap: (){
        print('新消息提醒');
      },
      child: Container(
        padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
        decoration: BoxDecoration(
            color: isDark ? ThemeColors.dark_colorWhite : ThemeColors.colorWhite
        ),
        child: Column(
          children: <Widget>[
            Container(
                padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(39), 0.0, ScreenUtil().setWidth(39)),
                child:Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      child: Text(
                        Strings.STTINGADVICE,
                        style: isDark ? WordStyles.dark_fontSize28color333 : WordStyles.fontSize28color333,
                      ),
                    ),
                    new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(10),)
                  ],
                )
            ),
          ],
        ),
      ),
    );
  }

  //夜间模式
  Widget nightMode(BuildContext context,isDark){
    return GestureDetector(
      onTap: (){
        print('夜间模式');
        NavigatorUtils.themePage(context);
      },
      child: Container(
        padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
        decoration: BoxDecoration(
            color: isDark ? ThemeColors.dark_colorWhite : ThemeColors.colorWhite
        ),
        child: Column(
          children: <Widget>[
            Container(
                padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(39), 0.0, ScreenUtil().setWidth(39)),
                child:Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      child: Text(
                        Strings.NIGHT_MODE,
                        style: isDark ? WordStyles.dark_fontSize28color333 : WordStyles.fontSize28color333,
                      ),
                    ),
                    Row(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(right: 10.0),
                          child: Text(
                            themeMode,
                            style:isDark ? WordStyles.dark_fontSize28color999 : WordStyles.fontSize28color999 ,
                          ),
                        ),
                        new Image(image: new AssetImage('images/img_m4.png'),width: ScreenUtil().setWidth(10),)
                      ],
                    )
                  ],
                )
            ),
          ],
        ),
      ),
    );
  }

  //退出登录
  Widget exitLogin(isDark){
    return Container(
      margin: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30),ScreenUtil().setWidth(186), ScreenUtil().setWidth(30), ScreenUtil().setWidth(65)),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color:isDark ?  ThemeColors.dark_colorF7F7F7 : ThemeColors.colorF7F7F7,
        border: Border.all(
          color:isDark ? ThemeColors.dark_colorNavyBlue:ThemeColors.colorNavyBlue
        ),
        borderRadius: BorderRadius.circular(5)
      ),
      padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(25), 0.0, ScreenUtil().setWidth(25)),
      child: Text(
        Strings.LOGIN_OUT,
        style:isDark ? WordStyles.dark_fontSize28colorNavyBlueBold : WordStyles.fontSize28colorNavyBlueBold,
      ),
    );
  }
}


