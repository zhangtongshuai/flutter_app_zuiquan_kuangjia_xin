import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';
import 'package:flutter_app_jimoshangguan/utils/theme_utils.dart';
class userAddress extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<userAddress> {
  @override
  TextEditingController userAddAddressText = TextEditingController();
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    bool isDark = ThemeUtils.isDark(context);
    return layout(context,isDark);
  }

  Widget layout(BuildContext context,isDark) {
    return new Scaffold(
      appBar:PreferredSize(
          child:AppBar(
            elevation: 0.2,
            centerTitle: true,
            iconTheme: IconThemeData(),
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios),
              color:isDark ? ThemeColors.dark_backColor : ThemeColors.backColor,
              iconSize: ScreenUtil().setSp(42),
              onPressed: (){
                Navigator.of(context).pop();				//退出弹出框
              },
            ),
            title: new Text(
              Strings.ADDRESS,
              textAlign:TextAlign.center,
              style:isDark?WordStyles.dark_fontSize36color333333:WordStyles.fontSize36color333333,
            ),
            actions: <Widget>[
              Container(
                padding:EdgeInsets.fromLTRB(0.0, 0.0, ScreenUtil().setWidth(30), 0.0),
                height: ScreenUtil().setWidth(92),
                alignment: Alignment.centerLeft,
                child: InkWell(
                  onTap: (){
                    print("完成");
                  },
                  child:Text(Strings.COMPLETE,style:isDark ? WordStyles.dark_fontSize32colorBtnTop : WordStyles.fontSize32colorBtnTop,),
                )
              )
            ],
            backgroundColor: isDark ? ThemeColors.dark_colorF7F7F7Head : ThemeColors.colorF7F7F7Head,
          ),
          preferredSize: Size.fromHeight(ScreenUtil().setWidth(92))),
          body: new ListView(
            children: <Widget>[
              addressTitle(Strings.ADDRESS_TITLE,isDark),
              addressList(0,isDark),
              addressTitle(Strings.ADDRESS_HISTORY,isDark),
              addressList(1,isDark),
              addressTitle(Strings.ADDRESS_EDITE,isDark),
              addressEdit(isDark)
            ],
          ),
      );
  }
  //标题
  Widget addressTitle(titlename,isDark){
    return Container(
      padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(29), ScreenUtil().setWidth(11), ScreenUtil().setWidth(29), ScreenUtil().setWidth(11)),
      decoration: BoxDecoration(
        color: isDark?ThemeColors.dark_colorF7F7F7:ThemeColors.colorF7F7F7
      ),
      child: Text(
        titlename,
        style: isDark?WordStyles.dark_fontSize24color999:WordStyles.fontSize24color999,
      ),
    );
  }
  //地址列表
  Widget addressList(state,isDark){
    return Container(
      padding: EdgeInsets.all(ScreenUtil().setWidth(30)),
      decoration: BoxDecoration(
        color: isDark?ThemeColors.dark_colorWhite:ThemeColors.colorWhite
      ),
      child:Row(
        children: <Widget>[
          new Image(image: state==0?new AssetImage('images/iconc2.png'):new AssetImage('images/iconc1.png'),width: ScreenUtil().setWidth(28),),
          SizedBox(width: ScreenUtil().setWidth(18),),
          Expanded(
            child: Container(
              width: ScreenUtil().setWidth(500),
              child: Text(
               "山东省 青岛市青岛市 李先生   130-6589-8423",
                style:isDark?WordStyles.dark_fontSize28color333:WordStyles.fontSize28color333,
              ),
            ),
          ),
          SizedBox(width: ScreenUtil().setWidth(28),),
          InkWell(
            onTap: (){
              print("编辑");
            },
            child:Text(
              Strings.EDIT,
              style:isDark?WordStyles.dark_fontSize24colorThemeUnderline:WordStyles.fontSize24colorThemeUnderline,
            )
          ),
        ],
      ),
    );
  }
  
  //新增修改地址
  Widget addressEdit(isDark){
     return Container(
       margin: EdgeInsets.all(ScreenUtil().setWidth(30)),
       padding: EdgeInsets.all(ScreenUtil().setWidth(20)),
       width: ScreenUtil().setWidth(690),
       height: ScreenUtil().setWidth(195),
       decoration: BoxDecoration(
         color:isDark?ThemeColors.dark_colorF7F7F7:ThemeColors.colorF7F7F7,
         border:Border.all(
           color:isDark?ThemeColors.dark_colorE6E6E6:ThemeColors.colorE6E6E6,
         )
       ),
       child:Column(
         crossAxisAlignment: CrossAxisAlignment.start,
         children: <Widget>[
           Container(
             alignment: Alignment.topLeft,
             width: ScreenUtil().setWidth(650),
             child: new TextField(
               obscureText: false,
               textAlign:TextAlign.left,
               controller: userAddAddressText,
               keyboardType: TextInputType.number,
               maxLines: 3,
               decoration: InputDecoration(
                   contentPadding: const EdgeInsets.symmetric(vertical:0.0),
                   border: InputBorder.none,
                   hintText: "",
                   hintStyle: isDark?WordStyles.dark_fontSize28color5A6B79:WordStyles.fontSize28color5A6B79
               ),
               style:isDark?WordStyles.dark_fontSize28color5A6B79:WordStyles.fontSize28color5A6B79,
             ),
           ),
           Container(
             alignment: Alignment.bottomRight,
             child: Text(Strings.COMFRIME,style: isDark?WordStyles.dark_fontSize28colorcolorBtnTop:WordStyles.fontSize28colorcolorBtnTop,),
           )
         ],
       ),
     );
  }
}


