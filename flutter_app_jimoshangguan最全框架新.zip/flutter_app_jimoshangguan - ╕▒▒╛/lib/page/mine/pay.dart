import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/string.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_app_jimoshangguan/widgets/userCard.dart';
import 'package:flutter_app_jimoshangguan/utils/navigator_util.dart';
class becomePay extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<becomePay> {
  @override
  var payTypein=0;
  Widget build(BuildContext context) {
    ScreenUtil.init(context, width: 750, height: 1334, allowFontScaling: true);
    return Scaffold(
      backgroundColor: ThemeColors.colorLight,
      body: new SingleChildScrollView(//SingleChildScrollView
        child: Container(
          child: Column(
            children: <Widget>[
              new Column(
                children: <Widget>[
                  header(context),
                  payType(),
                  comfrimPay(context),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget header(context){
    return Stack(
      children: <Widget>[
        Column(
          children: <Widget>[
            Container(
                width: double.infinity,
                height: ScreenUtil().setWidth(280),
                padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30),ScreenUtil().setWidth(80), ScreenUtil().setWidth(30),0.0),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      ThemeColors.colorBtnFoot,
                      ThemeColors.colorBtnTop,
                    ],
                  ),
                ),
                child:Container(
                    alignment: Alignment.topLeft,
                    child:Column(
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            InkWell(
                              onTap:(){
                                Navigator.of(context).pop();				//退出弹出框
                              },
                              child:new Image(image: new AssetImage('images/backicon.png'),width: ScreenUtil().setWidth(18),),
                            ),
                            SizedBox(width: ScreenUtil().setWidth(20),),
                            Text(
                              Strings.MINE_BECOME,
                              style: WordStyles.fontSize36colorWhite,
                            ),
                          ],
                        ),
                      ],
                    )
                )
            ),
            Container(
              height:ScreenUtil().setWidth(100),
            )
          ],
        ),
        Positioned(
            top: ScreenUtil().setWidth(168),
            child: payNum()
        ),
      ],
    );
  }
  //今日收入
  Widget payNum(){
    return Container(
        width: ScreenUtil().setWidth(690),
        alignment: Alignment.center,
        margin:EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), 0.0, ScreenUtil().setWidth(30), 0.0),
        padding: EdgeInsets.all(ScreenUtil().setWidth(30)),
        decoration: BoxDecoration(
            color: ThemeColors.colorWhite,
            boxShadow: [
              BoxShadow(color: Color(0x11333333), offset: Offset(2,ScreenUtil().setWidth(16)),blurRadius: ScreenUtil().setWidth(15), spreadRadius: 3)
            ],
            borderRadius: BorderRadius.circular(ScreenUtil().setWidth(15))
        ),
        child:Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                point(),
                SizedBox(width: ScreenUtil().setWidth(14),),
                point(),
                Container(
                  padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(28), 0.0, ScreenUtil().setWidth(28), 0.0),
                  child: Text(Strings.MINE_BECOMEPAY,style: WordStyles.fontSize28color333,),
                ),
                point(),
                SizedBox(width: ScreenUtil().setWidth(14),),
                point(),
              ],
            ),
            SizedBox(height: ScreenUtil().setWidth(30),),
            Price(),
          ],
        )
    );
  }

  Widget point(){
    return Container(
      width: ScreenUtil().setWidth(11),
      height: ScreenUtil().setWidth(11),
      decoration: BoxDecoration(
          color: ThemeColors.colorFF9813,
          borderRadius: BorderRadius.circular(60)
      ),
    );
  }

  Widget Price(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        Text(Strings.DOLLAR,style: WordStyles.fontSize28colorFF9813,),
        Text("888",style: WordStyles.fontSize42colorFF9813,),
        Text(".00",style: WordStyles.fontSize28colorFF9813,)
      ],
    );
  }

  Widget payType(){
    return Container(
      width: ScreenUtil().setWidth(690),
      padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(20),0.0,ScreenUtil().setWidth(20), 0.0),
      decoration: BoxDecoration(
          color: ThemeColors.colorWhite,
          borderRadius: BorderRadius.circular(ScreenUtil().setWidth(5))
      ),
      child: Column(
        children: <Widget>[
          InkWell(
            onTap: (){
              setState(() {
                payTypein=0;
              });
            },
            child: Container(
              padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          color: ThemeColors.colorE6E6E6
                      )
                  )
              ),
              child: Row(
                children: <Widget>[
                  new Image(image: new AssetImage('images/zfb.png'),width: ScreenUtil().setWidth(78),),
                  SizedBox(width: ScreenUtil().setWidth(29)),
                  Expanded(
                      child:Text(Strings.PAYALIPAY,style: WordStyles.fontSize28color333,)
                  ),
                  new Image(image: payTypein==0?new AssetImage('images/iconp01.png'):new AssetImage('images/iconp02.png'),width: ScreenUtil().setWidth(25),),
                ],
              ),
            ),
          ),
          InkWell(
            onTap: (){
              setState(() {
                payTypein=1;
              });
            },
            child: Container(
              padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(30),0.0,ScreenUtil().setWidth(30)),
              child: Row(
                children: <Widget>[
                  new Image(image: new AssetImage('images/wx.png'),width: ScreenUtil().setWidth(78),),
                  SizedBox(width: ScreenUtil().setWidth(29)),
                  Expanded(
                      child:Text(Strings.PAYWECHATR,style: WordStyles.fontSize28color333,)
                  ),
                  new Image(image: payTypein==1?new AssetImage('images/iconp01.png'):new AssetImage('images/iconp02.png'),width: ScreenUtil().setWidth(25),),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
//确认支付
  Widget comfrimPay(BuildContext context){
    return Container(
      margin: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30),ScreenUtil().setWidth(440), ScreenUtil().setWidth(30), ScreenUtil().setWidth(65)),
      alignment: Alignment.center,
      decoration:WordStyles.btnStyle,
      padding: EdgeInsets.fromLTRB(0.0, ScreenUtil().setWidth(25), 0.0, ScreenUtil().setWidth(25)),
      child: Text(
        Strings.CONFIRMPAY,
        style: WordStyles.fontSize28colorNavyBlue,
      ),
    );
  }
}










