import 'package:flutter/material.dart';

class LoginModel with ChangeNotifier {
  int _loginIndex = 0;
  int get current => _loginIndex;
  void increment(current){
    _loginIndex = current;
    notifyListeners();
  }
}
