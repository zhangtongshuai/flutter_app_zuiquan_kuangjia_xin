import 'dart:ui';

import 'package:flustars/flustars.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_jimoshangguan/common/common.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/constant/wordStyle.dart';

class ThemeProvider extends ChangeNotifier {

  static const Map<ThemeMode, String> themes = {
    ThemeMode.dark: 'Dark', ThemeMode.light : 'Light', ThemeMode.system : 'System'
  };
  
  void syncTheme() {
    String theme = SpUtil.getString(Constant.theme);
    if (theme.isNotEmpty && theme != themes[ThemeMode.system]) {
      notifyListeners();
    }
  }

  void setTheme(ThemeMode themeMode) {
    SpUtil.putString(Constant.theme, themes[themeMode]);
    notifyListeners();
  }

  ThemeMode getThemeMode(){
    String theme = SpUtil.getString(Constant.theme);
    switch(theme) {
      case 'Dark':
        return ThemeMode.dark;
      case 'Light':
        return ThemeMode.light;
      default:
        return ThemeMode.system;
    }
  }

  getTheme({bool isDarkMode: false}) {
    return ThemeData(
      errorColor: isDarkMode ? ThemeColors.dark_colorRed2 : ThemeColors.colorRed2,
      brightness: isDarkMode ? Brightness.dark : Brightness.light,
      primaryColor: isDarkMode ? ThemeColors.dark_colorTheme : ThemeColors.colorTheme,
      accentColor: isDarkMode ? ThemeColors.dark_colorTheme : ThemeColors.colorTheme,
      // Tab指示器颜色
      indicatorColor: isDarkMode ? ThemeColors.dark_colorTheme : ThemeColors.colorTheme,
      // 页面背景色
      scaffoldBackgroundColor: isDarkMode ? ThemeColors.dark_colorWhite : ThemeColors.colorWhite,
      // 主要用于Material背景色
      canvasColor: isDarkMode ? ThemeColors.dark_colorWhite : ThemeColors.colorWhite,
      // 文字选择色（输入框复制粘贴菜单）
      textSelectionColor: ThemeColors.colorTheme.withAlpha(70),
      textSelectionHandleColor: ThemeColors.colorTheme,
      textTheme: TextTheme(
        // TextField输入文字颜色
        subhead: isDarkMode ? WordStyles.dark_fontSize14color333 : WordStyles.fontSize14color333,
        // Text文字样式
        body1: isDarkMode ? WordStyles.dark_fontSize14color333 : WordStyles.fontSize14color333,
        subtitle: isDarkMode ? WordStyles.dark_fontSize12color999 : WordStyles.fontSize12color999,
      ),
      inputDecorationTheme: InputDecorationTheme(
        hintStyle: isDarkMode ? WordStyles.fontSize12color999 : WordStyles.dark_fontSize12color999,
      ),
      appBarTheme: AppBarTheme(
        elevation: 0.0,
        color: isDarkMode ? ThemeColors.dark_colorWhite : ThemeColors.colorWhite,
        brightness: isDarkMode ? Brightness.dark : Brightness.light,
      ),
      dividerTheme: DividerThemeData(
        color: isDarkMode ? ThemeColors.dark_colorE6E6E6 : ThemeColors.colorE6E6E6,
        space: 0.6,
        thickness: 0.6
      ),
      cupertinoOverrideTheme: CupertinoThemeData(
        brightness: isDarkMode ? Brightness.dark : Brightness.light,
      )
    );
  }

}