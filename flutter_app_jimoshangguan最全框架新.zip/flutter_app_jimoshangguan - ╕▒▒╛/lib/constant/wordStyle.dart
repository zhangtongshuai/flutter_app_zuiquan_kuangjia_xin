import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
class WordStyles {

  static TextStyle fontSize12color999 = TextStyle(
    fontSize:12.0,
    color: ThemeColors.color999999,
  );

  static TextStyle dark_fontSize12color999 = TextStyle(
    fontSize:12.0,
    color: ThemeColors.dark_color999999,
  );

  static TextStyle fontSize12color333 = TextStyle(
    fontSize:12.0,
    color: ThemeColors.color333333,
  );

  static TextStyle dark_fontSize12color333 = TextStyle(
    fontSize:12.0,
    color: ThemeColors.dark_color333333,
  );
  static TextStyle fontSize14color333 = TextStyle(
    fontSize:14.0,
    color: ThemeColors.color333333,
  );
  static TextStyle dark_fontSize14color333 = TextStyle(
    fontSize:14.0,
    color: ThemeColors.dark_color333333,
  );
  static TextStyle fontSize16color666 = TextStyle(
    fontSize:ScreenUtil().setSp(16),
    color: ThemeColors.color666666,
  );

  static TextStyle dark_fontSize16color666 = TextStyle(
    fontSize:ScreenUtil().setSp(16),
    color: ThemeColors.dark_color666666,
  );

  static TextStyle fontSize22color999 = TextStyle(
    fontSize:ScreenUtil().setSp(22),
    color: ThemeColors.color999999,
  );

  static TextStyle dark_fontSize22color999 = TextStyle(
    fontSize:ScreenUtil().setSp(22),
    color: ThemeColors.dark_color999999,
  );

  static TextStyle fontSize24color333 = TextStyle(
    fontSize:ScreenUtil().setSp(24),
    color: ThemeColors.color333333,
  );

  static TextStyle dark_fontSize24color333 = TextStyle(
    fontSize:ScreenUtil().setSp(24),
    color: ThemeColors.dark_color333333,
  );

  static TextStyle fontSize24color666 = TextStyle(
    fontSize:ScreenUtil().setSp(24),
    color: ThemeColors.color666666,
  );

  static TextStyle dark_fontSize24color666 = TextStyle(
    fontSize:ScreenUtil().setSp(24),
    color: ThemeColors.dark_color666666,
  );

  static TextStyle fontSize24colorTheme = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.colorTheme,
  );
  static TextStyle dark_fontSize24colorTheme = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.dark_colorTheme,
  );
  static TextStyle fontSize24colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.colorWhite,
  );
  static TextStyle dark_fontSize24colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.dark_colorWhite,
  );
  static TextStyle dark_fontSize24colorCCC = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.dark_colorCCCCCC,
  );
  static TextStyle fontSize24color999 = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.color999999,
  );
  static TextStyle dark_fontSize24color999 = TextStyle(
    fontSize: ScreenUtil().setSp(24),
    color: ThemeColors.dark_color999999,
  );

  static TextStyle fontSize24colorThemeUnderline = TextStyle(
    color: ThemeColors.colorTheme,
    fontSize: ScreenUtil().setSp(24),
    decoration: TextDecoration.underline,
    decorationColor: ThemeColors.colorTheme,
  );
  static TextStyle dark_fontSize24colorThemeUnderline = TextStyle(
    color: ThemeColors.colorTheme,
    fontSize: ScreenUtil().setSp(24),
    decoration: TextDecoration.underline,
    decorationColor: ThemeColors.dark_colorTheme,
  );
  static TextStyle fontSize26colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(26),
    color: ThemeColors.colorWhite,
  );
  static TextStyle dark_fontSize26colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(26),
    color: ThemeColors.dark_colorWhite,
  );
  static TextStyle fontSize26color333DecNot = TextStyle(
    fontSize: ScreenUtil().setSp(26),
    color: ThemeColors.color333333,
    decoration: TextDecoration.none,
  );
  static TextStyle dark_fontSize26color333DecNot = TextStyle(
    fontSize: ScreenUtil().setSp(26),
    color: ThemeColors.dark_color333333,
    decoration: TextDecoration.none,
  );
  static TextStyle fontSize28colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.colorWhite,
  );
  static TextStyle dark_fontSize28colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.dark_colorWhite,
  );
  static TextStyle fontSize28colorTheme = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.colorTheme,
  );
  static TextStyle dark_fontSize28colorTheme = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.dark_colorTheme,
  );
  static TextStyle fontSize28color333 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.color333333,
  );
  static TextStyle dark_fontSize28color333 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.dark_color333333,
  );
  static TextStyle fontSize28color999 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.color999999,
  );
  static TextStyle dark_fontSize28color999 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.dark_color999999,
  );
  static TextStyle fontSize28color5A6B79 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.color5A6B79,
  );
  static TextStyle dark_fontSize28color5A6B79 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.dark_color5A6B79,
  );
  static TextStyle fontSize28colorNavyBlue = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.colorNavyBlue,
  );
  static TextStyle dark_fontSize28colorNavyBlue = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.dark_colorNavyBlue,
  );
  static TextStyle fontSize28color666666 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.color666666,
  );
  static TextStyle dark_fontSize28color666666 = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.dark_color666666,
  );
  static TextStyle fontSize28color6999F1= TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.color6999F1,
  );
  static TextStyle dark_fontSize28color6999F1= TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.dark_color6999F1,
  );
  static TextStyle fontSize28colorNavyBlueBold = TextStyle(
    fontSize: ScreenUtil().setSp(28),
    color: ThemeColors.colorNavyBlue,
    fontWeight: FontWeight.bold
  );

  static TextStyle dark_fontSize28colorNavyBlueBold = TextStyle(
      fontSize: ScreenUtil().setSp(28),
      color: ThemeColors.dark_colorNavyBlue,
      fontWeight: FontWeight.bold
  );

  static TextStyle fontSize28colorcolorBtnTop = TextStyle(
      fontSize: ScreenUtil().setSp(28),
      color: ThemeColors.colorBtnTop
  );
  static TextStyle dark_fontSize28colorcolorBtnTop = TextStyle(
      fontSize: ScreenUtil().setSp(28),
      color: ThemeColors.dark_colorBtnTop
  );
  static TextStyle fontSize28colorFF9813 = TextStyle(
      fontSize: ScreenUtil().setSp(28),
      color: ThemeColors.colorFF9813
  );
  static TextStyle dark_fontSize28colorFF9813 = TextStyle(
      fontSize: ScreenUtil().setSp(28),
      color: ThemeColors.dark_colorFF9813
  );
  static TextStyle fontSize30colorBFBFBF = TextStyle(
    fontSize: ScreenUtil().setSp(30),
    color: ThemeColors.colorBFBFBF,
  );
  static TextStyle dark_fontSize30colorBFBFBF = TextStyle(
    fontSize: ScreenUtil().setSp(30),
    color: ThemeColors.dark_colorBFBFBF,
  );
  static TextStyle fontSize32colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.colorWhite,
  );
  static TextStyle dark_fontSize32colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.dark_colorWhite,
  );
  static TextStyle fontSize32color333DecNot = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.color333333,
    decoration: TextDecoration.none,
  );
  static TextStyle dark_fontSize32color333DecNot = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.dark_color333333,
    decoration: TextDecoration.none,
  );
  static TextStyle fontSize32colorRed2 = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.colorRed2,
  );
  static TextStyle dark_fontSize32colorRed2 = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.dark_colorRed2,
  );
  static TextStyle fontSize32colorBtnTop = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.colorBtnTop,
  );
  static TextStyle dark_fontSize32colorBtnTop = TextStyle(
    fontSize: ScreenUtil().setSp(32),
    color: ThemeColors.dark_colorNavyBlue,
  );
  static TextStyle fontSize36colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(36),
    color: ThemeColors.colorWhite,
  );
  static TextStyle dark_fontSize36colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(36),
    color: ThemeColors.dark_colorWhite,
  );
  static TextStyle fontSize36color333333 = TextStyle(
    fontSize: ScreenUtil().setSp(36),
    color: ThemeColors.color333333,
  );

  static TextStyle dark_fontSize36color333333 = TextStyle(
    fontSize: ScreenUtil().setSp(36),
    color: ThemeColors.dark_color333333,
  );

  static TextStyle dark_fontSize36colorCCC = TextStyle(
    fontSize: ScreenUtil().setSp(36),
    color: ThemeColors.dark_colorCCCCCC,
  );

  static TextStyle fontSize42colorFF9813 = TextStyle(
      fontSize: ScreenUtil().setSp(42),
      color: ThemeColors.colorFF9813
  );
  static TextStyle dark_fontSize42colorFF9813 = TextStyle(
      fontSize: ScreenUtil().setSp(42),
      color: ThemeColors.dark_colorFF9813
  );

  static TextStyle fontSize60colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(60),
    color: ThemeColors.colorWhite,
  );
  static TextStyle dark_fontSize60colorWhite = TextStyle(
    fontSize: ScreenUtil().setSp(60),
    color: ThemeColors.dark_colorWhite,
  );
  static BoxDecoration btnStyle=BoxDecoration(
      color:ThemeColors.colorF7F7F7,
      border: Border.all(
          color:ThemeColors.colorNavyBlue
      ),
      borderRadius: BorderRadius.circular(5)
  );

  static BoxDecoration dark_btnStyle=BoxDecoration(
      color:ThemeColors.dark_colorF7F7F7,
      border: Border.all(
          color:ThemeColors.dark_colorNavyBlue
      ),
      borderRadius: BorderRadius.circular(5)
  );

}