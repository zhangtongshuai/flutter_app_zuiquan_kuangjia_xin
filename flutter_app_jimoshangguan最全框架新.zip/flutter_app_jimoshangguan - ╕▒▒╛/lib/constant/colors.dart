import 'package:flutter/material.dart';
class ThemeColors {
  ///主色调，按钮，特殊需要强调和突出的文字
  static Color colorTheme = Color(0xff538AEF);
  static Color dark_colorTheme = Color(0xff538AEF);
  ///主色调渐变用色，个别按钮和状态，从colorBtnTop变化到colorBtnBottom
  static Color colorBtnTop = Color(0xff538AEF);
  static Color dark_colorBtnTop = Color(0xff000000);
  static Color colorBtnBottom = Color(0xff1CC5E9);
  static Color dark_colorBtnBottom = Color(0xff555555);
  static Color colorBtnFoot = Color(0xff20CFAC);
  static Color dark_colorBtnFoot = Color(0xff20CFAC);
  //一些效果的背景色
  static Color colorBack = Color(0xff14233C);
  static Color dark_colorBack = Color(0xffEDEDED);
  ///纯黑色
  static Color colorBlack = Color(0xff000000);
  static Color dark_colorBlack = Color(0xffFFFFFF);
  //浅蓝色
  static Color colorWathet = Color(0xff80a6ec);
  static Color dark_colorWathet = Color(0xff80a6ec);
  static Color colorBlue = Color(0xff34D9FF);
  static Color dark_colorBlue = Color(0xff34D9FF);

  static Color color6999F1= Color(0xff6999F1);
  static Color dark_color6999F1= Color(0xff6999F1);

  static Color colorNavyBlue = Color(0xff25447D);
  static Color dark_colorNavyBlue = Color(0xff80a6ec);
  //价格红色
  static Color colorRed1 = Color(0xffFF0000);
  static Color dark_colorRed1 = Color(0xffFF0000);
  //提示红色
  static Color colorRed2 = Color(0xffE71F19);
  static Color dark_colorRed2 = Color(0xffE71F19);
  //按钮边框文字红色
  static Color colorRed3 = Color(0xffFF2D2D);
  static Color dark_colorRed3 = Color(0xffFF2D2D);
  //按钮边框文字红色
  static Color colorRed4 = Color(0xffFF1B1B);
  static Color dark_colorRed4 = Color(0xffFF1B1B);
  //黄色
  static Color colorYellow = Color(0xffFFA02E);
  static Color dark_colorYellow = Color(0xffFFA02E);

  static Color colorFF9813 = Color(0xffFF9813);
  static Color dark_colorFF9813 = Color(0xffFF9813);
  //纯白色
  static Color colorWhite = Color(0xffFFFFFF);
  static Color dark_colorWhite = Color(0xFF303233);
  ///提示性文字，状态信息，按钮等
  static Color colorGrey = Color(0xffEDEDED);
  static Color dark_colorGrey = Color(0xFF1F1F1F);
  ///功能性较强的文字，内页标题等
  static Color color333333 = Color(0xff333333);
  static Color dark_color333333 = Color(0xffB8B8B8);
  ///背景区域划分，分割线
  static Color colorE6E6E6 = Color(0xffE6E6E6);
  static Color dark_colorE6E6E6 = Color(0xff666666);

  ///正文，副标题以及可点击区域的主要文字和图标
  static Color color666666 = Color(0xff666666);
  static Color dark_color666666 = Color(0xffE6E6E6);

  ///弱化信息，提示性文字信息，不可点击状态
  static Color color999999 = Color(0xff999999);
  static Color dark_color999999 = Color(0xFF666666);

  ///弱化信息，提示性文字信息，不可点击状态
  static Color colorCCCCCC = Color(0xffCCCCCC);
  static Color dark_colorCCCCCC = Color(0xFFF2F2F2);

  static Color colorF7F7F7 = Color(0xffF7F7F7);
  static Color dark_colorF7F7F7 = Color(0xff454545);

  static Color colorF2F2F2 = Color(0xffF2F2F2);
  static Color dark_colorF2F2F2 = Color(0xffD2D2D2);

  static Color colorF7F7F7Head = Color(0xffF7F7F7);
  static Color dark_colorF7F7F7Head = Color(0xff303030);

  //浅色背景色
  static Color colorLight = Color(0xfffcf9fc);
  static Color dark_colorLight = Color(0xff666666);

  //透明灰色
  static Color colorHyaline =  Color.fromRGBO(0, 0, 0, 0.5);
  static Color dark_colorHyaline =  Color.fromRGBO(255, 255, 255, 0.5);
  //0.2度透明的颜色
  static Color colorWhiteLight = Color(0x11FFFFFF);
  static Color dark_colorWhiteLight = Color(0x11FFFFFF);
  //0.2度透明的颜色
  static Color colorBFBFBF = Color(0xffBFBFBF);
  static Color dark_colorBFBFBF = Color(0xffBFBFBF);
  static Color color0x11333 = Color(0x11333333);
  static Color dark_color0x11333 = Color(0x11ffffff);
  //返回按钮的颜色
  static Color backColor = Color(0xff313131);
  static Color dark_backColor = Color(0xffF2F2F2);
  //我的页面的那个背景         颜色
  static Color cameBACKGROUND = Color(0xFF2270B2);
  static Color dark_cameBACKGROUND = Color(0xFF2270B2);
  //我的页面设置下下线        颜色
  static Color settingUNDERLINE = Color(0xFFEBEBEB);
  static Color dark_settingUNDERLINE = Color(0xff666666);
  //我的页面设置右边       颜色
  static Color color5A6B79 = Color(0xFF5A6B79);
  static Color dark_color5A6B79 = Color(0xFF5A6B79);

  //我的页面设置右边       颜色
  static Color colorD9D9D9 = Color(0xFFD9D9D9);
  static Color dark_colorD9D9D9 = Color(0xFF625f5f);

}
