import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluro/fluro.dart';
import 'package:flutter_app_jimoshangguan/constant/colors.dart';
import 'package:flutter_app_jimoshangguan/config/routers.dart';
import 'package:flutter_app_jimoshangguan/config/application.dart';
import 'package:flutter_app_jimoshangguan/provider/user_info.dart';
import 'package:flutter_app_jimoshangguan/provider/maillist_index.dart';
import 'package:flutter_app_jimoshangguan/provider/login_index.dart';
import 'package:flutter_app_jimoshangguan/provider/theme_provider.dart';
import 'package:provider/provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_app_jimoshangguan/widgets/ChineseCupertinoLocalizations.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(MallApp());
}

class MallApp extends StatelessWidget {

  MallApp() {
    final router = Router();
    Routers.configureRoutes(router);
    Application.router = router;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.bottom]);     //默认隐藏顶部虚拟状态栏，获取焦点后展示状态栏，展示大小为去掉状态栏时整体大小；
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(statusBarColor: ThemeColors.colorHyaline));   //该属性仅用于 Android 设备且 SDK >= M 时，顶部状态栏颜色；
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(statusBarIconBrightness: Brightness.dark));  //该属性仅用于 Android 设备且 SDK >= M 时，顶部状态栏图标的亮度；但小菜感觉并不明显；
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(statusBarBrightness: Brightness.light));      //该属性仅用于 iOS 设备顶部状态栏亮度；
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);   ////强制竖屏 竖直方向
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => UserInfoModel()),
        ChangeNotifierProvider(create: (_) => LoginModel()),
        ChangeNotifierProvider(create: (_) => MaillistModel()),
      ],
      child: Consumer<ThemeProvider>(builder: (context, provider, _){
        return MaterialApp(
          debugShowCheckedModeBanner: false, // 去除debug旗标
          onGenerateRoute: Application.router.generator,
          theme: provider.getTheme(),
          darkTheme: provider.getTheme(isDarkMode: true),
          themeMode: provider.getThemeMode(),
          localizationsDelegates: [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            ChineseCupertinoLocalizations.delegate,
          ],
          supportedLocales: [Locale('en', 'US'), Locale('zh', 'CH')],
          builder: (context, child) {
            /// 保证文字大小不受手机系统设置影响 https://www.kikt.top/posts/flutter/layout/dynamic-text/
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0), // 或者 MediaQueryData.fromWindow(WidgetsBinding.instance.window).copyWith(textScaleFactor: 1.0),
              child: child,
            );
          },
        );
      }),
    );
  }
}
